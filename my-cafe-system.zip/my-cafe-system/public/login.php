<?php
session_start();

// ถ้าล็อกอินอยู่แล้ว ให้เด้งไปหน้าตามสิทธิ์
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    $redirect = ($_SESSION['admin_role'] === 'admin' || $_SESSION['admin_role'] === 'superadmin') ? 'admin_dashboard.php' : 'admin_orders.php';
    header("Location: " . $redirect);
    exit;
}

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

$error = '';

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'shop_name'");
    $shop_name = $stmt->fetchColumn() ?: 'My Cafe';
    
    $stmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'primary_color'");
    $primary_color = $stmt->fetchColumn() ?: '#3b82f6';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['admin_role'] = $user['role'];
            $_SESSION['admin_username'] = $user['username'];
            
            // --- ส่วนที่เพิ่มใหม่: ดึง branch_id มาเก็บใน Session ---
            $_SESSION['branch_id'] = $user['branch_id']; 
            
            // เปลี่ยนทางตามสิทธิ์ที่ล็อกอิน
            $redirect = ($user['role'] === 'admin' || $user['role'] === 'superadmin') ? 'admin_dashboard.php' : 'admin_orders.php';
            header("Location: " . $redirect);
            exit;
        } else {
            $error = 'ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง';
        }
    }
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบ - <?php echo htmlspecialchars($shop_name); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center p-4">
    <div class="bg-white p-8 rounded-xl shadow-md w-full max-w-md">
        <div class="text-center mb-8">
            <div class="w-16 h-16 rounded-full mx-auto flex items-center justify-center text-white mb-4 shadow-lg"
                 style="background-color: <?php echo htmlspecialchars($primary_color); ?>;">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
            </div>
            <h1 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($shop_name); ?></h1>
            <p class="text-gray-500 text-sm mt-1">ระบบบริหารจัดการร้าน (Admin Panel)</p>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-100 text-red-700 p-3 rounded-lg text-sm mb-4 text-center"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php" class="space-y-5">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">ชื่อผู้ใช้งาน (Username)</label>
                <input type="text" name="username" required autocomplete="off" class="w-full border border-gray-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">รหัสผ่าน (Password)</label>
                <input type="password" name="password" required class="w-full border border-gray-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>
            <button type="submit" class="w-full text-white font-bold py-3 rounded-lg shadow-lg hover:opacity-90 transition"
                    style="background-color: <?php echo htmlspecialchars($primary_color); ?>;">
                เข้าสู่ระบบ
            </button>
        </form>
    </div>
</body>
</html>