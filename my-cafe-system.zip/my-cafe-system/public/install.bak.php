<?php
session_start();
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === 2) {
    // 1. รับค่าจากฟอร์ม
    $db_host = $_POST['db_host'];
    $db_name = $_POST['db_name'];
    $db_user = $_POST['db_user'];
    $db_pass = $_POST['db_pass'];
    
    $admin_user = $_POST['admin_user'];
    $admin_pass = password_hash($_POST['admin_pass'], PASSWORD_DEFAULT);
    $shop_name = $_POST['shop_name'];

    try {
        // 2. ทดสอบการเชื่อมต่อ Database
        $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // 3. อ่านและรันไฟล์ install.sql
        $sql_file = __DIR__ . '/../database/install.sql';
        if (!file_exists($sql_file)) {
            throw new Exception("ไม่พบไฟล์ฐานข้อมูลที่: " . $sql_file);
        }
        $sql = file_get_contents($sql_file);
        $pdo->exec($sql);

        // 4. สร้างบัญชี Superadmin เริ่มต้น
        $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'superadmin')");
        $stmt->execute([$admin_user, $admin_pass]);

        // 5. อัปเดตชื่อร้านในตาราง settings
        $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'shop_name'");
        $stmt->execute([$shop_name]);

        // 6. สร้างไฟล์ .env (ซ่อนไว้นอกโฟลเดอร์ public)
        $env_content = "DB_HOST={$db_host}\nDB_DATABASE={$db_name}\nDB_USERNAME={$db_user}\nDB_PASSWORD={$db_pass}\n";
        file_put_contents(__DIR__ . '/../.env', $env_content);

        $step = 3; // ไปหน้าสำเร็จ
    } catch (Exception $e) {
        $error = "เกิดข้อผิดพลาด: " . $e->getMessage();
        $step = 1; // กลับไปหน้ากรอกข้อมูล
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ติดตั้งระบบ My Cafe System</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f3f4f6; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #3b82f6; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="password"] { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .btn { width: 100%; padding: 12px; background: #3b82f6; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; }
        .btn:hover { background: #2563eb; }
        .alert { padding: 15px; background: #fee2e2; color: #ef4444; border-radius: 4px; margin-bottom: 15px; }
        .success { text-align: center; color: #10b981; }
    </style>
</head>
<body>
    <div class="container">
        <?php if ($step === 1): ?>
            <h2>⚙️ ติดตั้งระบบจัดการคาเฟ่</h2>
            <?php if ($error): ?><div class="alert"><?php echo $error; ?></div><?php endif; ?>
            <form action="?step=2" method="POST">
                <h3>1. ตั้งค่าฐานข้อมูล (Database)</h3>
                <div class="form-group"><label>Database Host</label><input type="text" name="db_host" value="localhost" required></div>
                <div class="form-group"><label>Database Name</label><input type="text" name="db_name" required></div>
                <div class="form-group"><label>Database User</label><input type="text" name="db_user" required></div>
                <div class="form-group"><label>Database Password</label><input type="password" name="db_pass"></div>
                
                <hr style="margin: 30px 0; border: 0; border-top: 1px solid #eee;">
                
                <h3>2. ตั้งค่าร้านค้าและผู้ดูแลระบบ</h3>
                <div class="form-group"><label>ชื่อร้าน (Shop Name)</label><input type="text" name="shop_name" required></div>
                <div class="form-group"><label>Username (Admin)</label><input type="text" name="admin_user" value="admin" required></div>
                <div class="form-group"><label>Password (Admin)</label><input type="password" name="admin_pass" required></div>
                
                <button type="submit" class="btn">🚀 เริ่มการติดตั้ง</button>
            </form>
        
        <?php elseif ($step === 3): ?>
            <div class="success">
                <h2>✅ ติดตั้งระบบสำเร็จ!</h2>
                <p>ฐานข้อมูลและบัญชีผู้ดูแลระบบถูกสร้างเรียบร้อยแล้ว</p>
                <br>
                <strong style="color: #ef4444;">⚠️ สำคัญมาก: เพื่อความปลอดภัย กรุณาลบไฟล์ public/install.php ออกจากเซิร์ฟเวอร์ทันที!</strong>
                <br><br>
                <a href="index.php"><button class="btn">ไปที่หน้าแรกของระบบ</button></a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>