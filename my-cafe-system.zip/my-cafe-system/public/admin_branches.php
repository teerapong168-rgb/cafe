<?php
session_start();

if (empty($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
if ($_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
if ($_SESSION['admin_role'] !== 'superadmin') {
    header("Location: admin_dashboard.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt =$pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {$settings[$row['setting_key']] =$row['setting_value'];
    }

    // 1. สร้างตารางถ้ายังไม่มี
    $pdo->exec("CREATE TABLE IF NOT EXISTS `branches` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `name` VARCHAR(100) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    
    // 2. เช็กและสร้างคอลัมน์ address แยกต่างหาก (ถ้าไม่มีถึงจะสร้าง)
    $checkAddress =$pdo->query("SHOW COLUMNS FROM branches LIKE 'address'")->rowCount();
    if ($checkAddress == 0) {$pdo->exec("ALTER TABLE branches ADD COLUMN address TEXT NULL AFTER name");
    }

    // 3. เช็กและสร้างคอลัมน์ phone แยกต่างหาก (ถ้าไม่มีถึงจะสร้าง)
    $checkPhone =$pdo->query("SHOW COLUMNS FROM branches LIKE 'phone'")->rowCount();
    if ($checkPhone == 0) {$pdo->exec("ALTER TABLE branches ADD COLUMN phone VARCHAR(20) NULL");
    }

    // 4. ถ้าตารางว่างเปล่า ให้สร้างสาขาที่ 1 เป็นค่าเริ่มต้น
    $checkEmpty =$pdo->query("SELECT COUNT(*) FROM branches")->fetchColumn();
    if ($checkEmpty == 0) {$pdo->exec("INSERT INTO branches (id, name, address, phone) VALUES (1, 'สาขาหลัก (Head Office)', 'ยังไม่ได้ระบุที่อยู่', '-')");
    }

    // --- ระบบเพิ่ม/ลบสาขา ---
    if ($_SERVER['REQUEST_METHOD'] === 'POST' AND isset($_POST['action'])) {
        $action =$_POST['action'];

        if ($action === 'add') {
            $name = trim($_POST['name']);
            $address = trim($_POST['address']);
            $phone = trim($_POST['phone']);

            $insertStmt =$pdo->prepare("INSERT INTO branches (name, address, phone) VALUES (?, ?, ?)");
            $insertStmt->execute([$name, $address,$phone]);
            header("Location: admin_branches.php?msg=added");
            exit;
        }

        if ($action === 'delete') {
            $id = (int)$_POST['branch_id'];
            if ($id === 1) {
                header("Location: admin_branches.php?err=cannot_delete_main");
                exit;
            }
            try {
                $delStmt =$pdo->prepare("DELETE FROM branches WHERE id = ?");
                $delStmt->execute([$id]);
                header("Location: admin_branches.php?msg=deleted");
                exit;
            } catch (PDOException $e) {
                if ($e->getCode() == 23000) {
                    header("Location: admin_branches.php?err=in_use");
                    exit;
                } else {
                    die("Error: " . $e->getMessage());
                }
            }
        }
    }

    $branches =$pdo->query("SELECT * FROM branches ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>จัดการสาขา - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen pb-10">

    <header class="bg-gray-900 text-white p-4 shadow-md flex justify-between items-center sticky top-0 z-50 flex-wrap gap-4">
        <div class="flex items-center space-x-4">
            <h1 class="text-xl font-bold">👑 Super Admin: จัดการสาขา (Branch Management)</h1>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <a href="admin_dashboard.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">แดชบอร์ด</a>
            <a href="admin_orders.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">KDS</a>
            <a href="admin_branches.php" class="text-sm bg-teal-600 hover:bg-teal-700 px-3 py-2 rounded font-semibold transition shadow-sm">จัดการสาขา</a>
            <a href="admin_menu.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการเมนู</a>
            <a href="admin_tables.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการโต๊ะ & QR</a>
            <a href="admin_users.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการพนักงาน</a>
            <a href="admin_logs.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">ดู Logs</a>
            <a href="logout.php" class="text-sm bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded font-semibold transition ml-2">ออกจากระบบ</a>
        </div>
    </header>

    <main class="p-6 max-w-7xl mx-auto flex flex-col md:flex-row gap-6">
        
        <!-- ฟอร์มเพิ่มสาขา -->
        <div class="md:w-1/3">
            <div class="bg-white p-6 rounded-xl shadow-md sticky top-24">
                <h2 class="text-lg font-bold mb-4 border-b pb-2 text-gray-800">➕ เพิ่มสาขาใหม่</h2>
                
                <?php if (isset($_GET['err']) AND$_GET['err'] == 'in_use'): ?>
                    <div class="bg-yellow-100 text-yellow-800 border border-yellow-300 p-3 rounded text-sm mb-4 font-bold text-center">
                        ⚠️ ลบไม่ได้! มีข้อมูลพนักงาน หรือ โต๊ะ ผูกอยู่กับสาขานี้
                    </div>
                <?php endif; ?>
                <?php if (isset($_GET['err']) AND$_GET['err'] == 'cannot_delete_main'): ?>
                    <div class="bg-red-100 text-red-700 p-3 rounded text-sm mb-4 font-bold text-center">
                        ❌ ไม่สามารถลบสาขาหลัก (รหัส 1) ได้
                    </div>
                <?php endif; ?>

                <form action="admin_branches.php" method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="add">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">ชื่อสาขา</label>
                        <input type="text" name="name" required class="w-full border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-teal-500" placeholder="เช่น สาขาลาดพร้าว">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">เบอร์โทรศัพท์ (สาขา)</label>
                        <input type="text" name="phone" class="w-full border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-teal-500" placeholder="02-XXX-XXXX">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">ที่อยู่ / รายละเอียด</label>
                        <textarea name="address" rows="3" class="w-full border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-teal-500" placeholder="ระบุที่ตั้งสาขา..."></textarea>
                    </div>
                    
                    <button type="submit" class="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 rounded-lg transition mt-4 shadow-sm">
                        💾 บันทึกสาขา
                    </button>
                </form>
            </div>
        </div>

        <div class="md:w-2/3">
            <div class="bg-white p-6 rounded-xl shadow-md">
                <h2 class="text-lg font-bold mb-4 border-b pb-2 text-gray-800">🏪 รายชื่อสาขาทั้งหมด</h2>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 text-gray-600 text-sm border-b">
                                <th class="p-3">รหัส (Branch ID)</th>
                                <th class="p-3">ชื่อสาขา</th>
                                <th class="p-3">เบอร์ติดต่อ</th>
                                <th class="p-3 text-right">จัดการ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($branches as$b): ?>
                                <tr class="border-b hover:bg-gray-50">
                                    <td class="p-3">
                                        <span class="bg-gray-800 text-white px-3 py-1 rounded-full text-xs font-bold">
                                            ID: <?php echo $b['id']; ?>
                                        </span>
                                    </td>
                                    <td class="p-3 font-bold text-gray-800">
                                        <?php echo htmlspecialchars($b['name']); ?>
                                        <div class="text-xs text-gray-500 font-normal mt-1"><?php echo htmlspecialchars($b['address'] ?? ''); ?></div>
                                    </td>
                                    <td class="p-3 text-sm text-gray-600"><?php echo htmlspecialchars($b['phone'] ?? ''); ?></td>
                                    <td class="p-3 text-right">
                                        <?php if ($b['id'] !== 1): ?>
                                            <form action="admin_branches.php" method="POST" onsubmit="return confirm('🚨 ยืนยันการลบสาขา <?php echo htmlspecialchars($b['name']); ?> ใช่หรือไม่?\n\n(หากมีโต๊ะหรือพนักงานค้างอยู่จะลบไม่ได้)');">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="branch_id" value="<?php echo $b['id']; ?>">
                                                <button type="submit" class="text-xs font-bold px-3 py-1.5 rounded bg-red-100 text-red-700 hover:bg-red-200 transition">ลบ</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-xs text-gray-400 italic font-semibold">สาขาหลัก (ลบไม่ได้)</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

</body>
</html>