<?php
session_start();

// ตรวจสอบสิทธิ์การล็อกอิน
if (empty($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
if ($_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    $current_branch_id = $_SESSION['branch_id'] ?? null;
    
    // กำหนดตัวแปรเช็กสิทธิ์เพื่อใช้แสดงซ่อนเมนู
    $is_superadmin = ($_SESSION['admin_role'] === 'superadmin');
    $is_admin_level = in_array($_SESSION['admin_role'], ['superadmin', 'admin']);
    $is_manager_or_above = in_array($_SESSION['admin_role'], ['superadmin', 'admin', 'manager']);

    // ตัวแปรสำหรับเก็บยอดขายแยกสาขาวันนี้ (เฉพาะ Admin/Superadmin)
    $todayBranchSales = [];

    // --- ดึงข้อมูลสรุปยอดขาย (แยกตามสาขา) ---
    if ($is_superadmin) {
        // Super Admin เห็นยอดรวมทุกสาขา
        $todayStmt = $pdo->query("SELECT COUNT(id) as total_orders, SUM(total_amount) as total_sales FROM orders WHERE DATE(created_at) = CURDATE() AND status != 'voided'");
        $allTimeStmt = $pdo->query("SELECT SUM(total_amount) as all_time_sales FROM orders WHERE status = 'completed'");
        
        $topProducts = $pdo->query("
            SELECT p.name, p.image_url, SUM(oi.quantity) as total_sold 
            FROM order_items oi 
            JOIN products p ON oi.product_id = p.id 
            JOIN orders o ON oi.order_id = o.id 
            WHERE o.status != 'voided' 
            GROUP BY p.id 
            ORDER BY total_sold DESC LIMIT 5
        ")->fetchAll(PDO::FETCH_ASSOC);

        $historyOrders = $pdo->query("
            SELECT o.*, b.name as branch_name, t.table_number
            FROM orders o 
            LEFT JOIN branches b ON o.branch_id = b.id 
            LEFT JOIN tables t ON o.table_id = t.id
            ORDER BY o.created_at DESC LIMIT 50
        ")->fetchAll(PDO::FETCH_ASSOC);

        // ดึงยอดขายวันนี้แยกตามสาขา
        $branchSalesStmt = $pdo->query("
            SELECT b.name as branch_name, COUNT(o.id) as total_orders, SUM(o.total_amount) as total_sales 
            FROM branches b
            LEFT JOIN orders o ON b.id = o.branch_id AND DATE(o.created_at) = CURDATE() AND o.status != 'voided'
            GROUP BY b.id
            ORDER BY b.id ASC
        ");
        $todayBranchSales = $branchSalesStmt->fetchAll(PDO::FETCH_ASSOC);

    } else {
        // Admin, Manager และ Staff สาขา เห็นเฉพาะยอดของสาขาตัวเอง
        $todayStmt = $pdo->prepare("SELECT COUNT(id) as total_orders, SUM(total_amount) as total_sales FROM orders WHERE DATE(created_at) = CURDATE() AND status != 'voided' AND branch_id = ?");
        $todayStmt->execute([$current_branch_id]);
        
        $allTimeStmt = $pdo->prepare("SELECT SUM(total_amount) as all_time_sales FROM orders WHERE status = 'completed' AND branch_id = ?");
        $allTimeStmt->execute([$current_branch_id]);
        
        $topProducts = $pdo->prepare("
            SELECT p.name, p.image_url, SUM(oi.quantity) as total_sold 
            FROM order_items oi 
            JOIN products p ON oi.product_id = p.id 
            JOIN orders o ON oi.order_id = o.id 
            WHERE o.status != 'voided' AND o.branch_id = ? 
            GROUP BY p.id 
            ORDER BY total_sold DESC LIMIT 5
        ");
        $topProducts->execute([$current_branch_id]);
        $topProducts = $topProducts->fetchAll(PDO::FETCH_ASSOC);

        $historyOrders = $pdo->prepare("
            SELECT o.*, b.name as branch_name, t.table_number
            FROM orders o 
            LEFT JOIN branches b ON o.branch_id = b.id 
            LEFT JOIN tables t ON o.table_id = t.id
            WHERE o.branch_id = ? 
            ORDER BY o.created_at DESC LIMIT 50
        ");
        $historyOrders->execute([$current_branch_id]);
        $historyOrders = $historyOrders->fetchAll(PDO::FETCH_ASSOC);
    }

    $todayData = $todayStmt->fetch(PDO::FETCH_ASSOC);
    $today_sales = $todayData['total_sales'] ?? 0;
    $today_orders = $todayData['total_orders'] ?? 0;

    $allTimeData = $allTimeStmt->fetch(PDO::FETCH_ASSOC);
    $all_time_sales = $allTimeData['all_time_sales'] ?? 0;

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

function getStatusLabel($status) {
    $map = [
        'pending' => '<span class="px-2 py-1 bg-red-100 text-red-700 rounded text-xs font-bold">รอดำเนินการ</span>',
        'processing' => '<span class="px-2 py-1 bg-yellow-100 text-yellow-700 rounded text-xs font-bold">กำลังทำ</span>',
        'ready_to_serve' => '<span class="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-bold">รอเสิร์ฟ</span>',
        'completed' => '<span class="px-2 py-1 bg-gray-200 text-gray-700 rounded text-xs font-bold">เสร็จสิ้น</span>',
        'voided' => '<span class="px-2 py-1 bg-red-600 text-white rounded text-xs font-bold">ยกเลิกบิล</span>',
    ];
    return $map[$status] ?? '<span class="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-bold">ไม่ทราบ</span>';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard สรุปยอดขาย - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen pb-10">

    <header class="bg-gray-900 text-white p-4 shadow-md flex justify-between items-center sticky top-0 z-50 flex-wrap gap-4">
        <div class="flex items-center space-x-4">
            <h1 class="text-xl font-bold">📊 Admin Dashboard</h1>
            <span class="bg-indigo-600 border border-indigo-400 text-xs px-2 py-1 rounded font-bold shadow-sm">
                <?php echo $is_superadmin ? '👑 สรุปยอดรวมทุกสาขา' : '📍 สรุปยอดเฉพาะสาขา: ' . ($current_branch_id); ?>
            </span>
        </div>
        
        <div class="flex flex-wrap items-center gap-2">
            <!-- เมนูที่พนักงานทั่วไปมองเห็นได้ -->
            <a href="admin_dashboard.php" class="text-sm bg-blue-600 hover:bg-blue-700 px-3 py-2 rounded font-semibold transition shadow-sm">แดชบอร์ด</a>
            <a href="admin_orders.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">KDS (รับออเดอร์)</a>
            
            <!-- เมนูที่ผู้จัดการขึ้นไปมองเห็นได้ -->
            <?php if ($is_manager_or_above): ?>
                <a href="admin_reports.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">รายงานยอดขาย</a>
            <?php endif; ?>

            <!-- เมนูเฉพาะ Super Admin -->
            <?php if ($is_superadmin): ?>
                <a href="admin_branches.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition text-yellow-300">จัดการสาขา</a>
                <a href="admin_reset.php" class="text-sm bg-red-800 hover:bg-red-700 text-red-100 px-3 py-2 rounded font-semibold transition shadow-sm border border-red-600">⚠️ ล้างข้อมูลระบบ</a>
            <?php endif; ?>
            
            <!-- เมนูที่เห็นเฉพาะ Admin และ Super Admin -->
            <?php if ($is_admin_level): ?>
                <a href="admin_menu.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการเมนู</a>
                <a href="admin_tables.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการโต๊ะ & QR</a>
                <a href="admin_users.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการพนักงาน</a>
            <?php endif; ?>
            
            <a href="admin_logs.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">ดู Logs</a>
            <a href="logout.php" class="text-sm bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded font-semibold transition ml-2">ออกจากระบบ</a>
        </div>
    </header>

    <main class="p-6 max-w-7xl mx-auto space-y-6">
        
        <!-- สรุปตัวเลขยอดขาย -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-sm border-l-4 border-blue-500 hover:shadow-md transition">
                <p class="text-gray-500 text-sm font-semibold mb-1">ยอดขายวันนี้ (บาท)</p>
                <h3 class="text-3xl font-black text-gray-800">฿<?php echo number_format($today_sales, 2); ?></h3>
            </div>
            <div class="bg-white p-6 rounded-xl shadow-sm border-l-4 border-green-500 hover:shadow-md transition">
                <p class="text-gray-500 text-sm font-semibold mb-1">จำนวนออเดอร์วันนี้</p>
                <h3 class="text-3xl font-black text-gray-800"><?php echo number_format($today_orders); ?> <span class="text-lg text-gray-400 font-normal">บิล</span></h3>
            </div>
            <div class="bg-white p-6 rounded-xl shadow-sm border-l-4 border-purple-500 hover:shadow-md transition">
                <p class="text-gray-500 text-sm font-semibold mb-1">ยอดขายรวมทั้งหมดที่ผ่านมา</p>
                <h3 class="text-3xl font-black text-gray-800">฿<?php echo number_format($all_time_sales, 2); ?></h3>
            </div>
        </div>

        <?php if ($is_superadmin && !empty($todayBranchSales)): ?>
        <!-- สรุปยอดขายประจำวันแยกตามสาขา (แสดงเฉพาะ Super Admin) -->
        <div class="bg-white p-6 rounded-xl shadow-sm">
            <h2 class="text-lg font-bold mb-4 border-b pb-2 text-gray-800">📊 สรุปยอดขายประจำวัน (แยกตามสาขา)</h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <?php foreach ($todayBranchSales as $bs): ?>
                    <div class="border rounded-lg p-4 bg-gray-50 hover:shadow-sm transition border-l-4 border-indigo-500">
                        <h3 class="font-bold text-gray-800 text-sm truncate"><?php echo htmlspecialchars($bs['branch_name']); ?></h3>
                        <p class="text-xl font-black text-indigo-600 mt-1">฿<?php echo number_format($bs['total_sales'] ?? 0, 2); ?></p>
                        <p class="text-xs text-gray-500 font-medium"><?php echo number_format($bs['total_orders'] ?? 0); ?> บิล</p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            <!-- ตารางออเดอร์ล่าสุด -->
            <div class="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm">
                <h2 class="text-lg font-bold mb-4 border-b pb-2 text-gray-800">📋 ประวัติการสั่งซื้อล่าสุด (50 รายการ)</h2>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 text-gray-600 text-sm border-b">
                                <th class="p-3">คิว / โต๊ะ</th>
                                <?php if ($is_superadmin): ?>
                                    <th class="p-3">สาขา</th>
                                <?php endif; ?>
                                <th class="p-3">วันที่ / เวลา</th>
                                <th class="p-3">วิธีชำระเงิน</th>
                                <th class="p-3">ยอดรวม</th>
                                <th class="p-3">สถานะ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($historyOrders)): ?>
                                <tr><td colspan="<?php echo $is_superadmin ? '6' : '5'; ?>" class="p-4 text-center text-gray-500">ยังไม่มีประวัติออเดอร์</td></tr>
                            <?php else: ?>
                                <?php foreach ($historyOrders as $ord): ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="p-3">
                                            <span class="font-bold text-blue-600 block"><?php echo htmlspecialchars($ord['queue_number']); ?></span>
                                            <span class="text-xs text-gray-500">โต๊ะ T-<?php echo $ord['table_number'] ? str_pad($ord['table_number'], 2, '0', STR_PAD_LEFT) : '--'; ?></span>
                                        </td>
                                        <?php if ($is_superadmin): ?>
                                            <td class="p-3 text-sm font-bold text-indigo-600">
                                                <?php echo htmlspecialchars($ord['branch_name'] ?? 'สาขา '.$ord['branch_id']); ?>
                                            </td>
                                        <?php endif; ?>
                                        <td class="p-3 text-sm text-gray-600"><?php echo date('d/m/Y H:i', strtotime($ord['created_at'])); ?></td>
                                        <td class="p-3 text-sm font-semibold text-gray-700"><?php echo $ord['payment_method'] == 'qr_promptpay' ? '📱 สแกนจ่าย' : '💵 เงินสด'; ?></td>
                                        <td class="p-3 font-bold text-gray-800">฿<?php echo number_format($ord['total_amount'], 2); ?></td>
                                        <td class="p-3"><?php echo getStatusLabel($ord['status']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- จัดอันดับสินค้าขายดี -->
            <div class="bg-white p-6 rounded-xl shadow-sm">
                <h2 class="text-lg font-bold mb-4 border-b pb-2 text-gray-800">🏆 5 อันดับเมนูขายดี</h2>
                <div class="space-y-4">
                    <?php if (empty($topProducts)): ?>
                        <p class="text-center text-gray-500 py-4">ยังไม่มีข้อมูลยอดขาย</p>
                    <?php else: ?>
                        <?php foreach ($topProducts as $index => $top): ?>
                            <div class="flex items-center space-x-4 bg-gray-50 p-3 rounded-lg border border-gray-100 hover:shadow-sm transition">
                                <div class="w-8 h-8 flex-shrink-0 bg-blue-100 text-blue-600 font-bold rounded-full flex items-center justify-center">#<?php echo $index + 1; ?></div>
                                <div class="flex-grow">
                                    <h3 class="font-bold text-sm text-gray-800"><?php echo htmlspecialchars($top['name']); ?></h3>
                                    <p class="text-xs text-gray-500">ขายแล้ว <span class="font-bold text-green-600"><?php echo $top['total_sold']; ?></span> แก้ว</p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
        </div>
    </main>

</body>
</html>