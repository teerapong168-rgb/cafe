<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';

        // ป้องกันพนักงานแอบยิง Request เพิ่ม/ลบ ผ่าน Postman หรือ Inspect Element
        if (($action === 'add' || $action === 'delete') && $_SESSION['admin_role'] !== 'admin') {
            die("คุณไม่มีสิทธิ์ดำเนินการนี้");
        }

        if ($action === 'add') {
            $name = $_POST['name'];
            $price = $_POST['price'];
            $category_id = $_POST['category_id'];
            $status = $_POST['status'];
            $image_url = '';

            if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
                $upload_dir = __DIR__ . '/uploads/products/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
                $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $filename = 'prod_' . time() . '_' . rand(100, 999) . '.' . $ext;
                if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $filename)) {
                    $image_url = '/uploads/products/' . $filename;
                }
            }

            $stmt = $pdo->prepare("INSERT INTO products (category_id, name, price, image_url, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$category_id, $name, $price, $image_url, $status]);
            header("Location: admin_menu.php?msg=added");
            exit;
        }

        if ($action === 'toggle_status') {
            $id = (int)$_POST['product_id'];
            $new_status = $_POST['new_status'];
            $stmt = $pdo->prepare("UPDATE products SET status = ? WHERE id = ?");
            $stmt->execute([$new_status, $id]);
            header("Location: admin_menu.php?msg=updated");
            exit;
        }

        if ($action === 'delete') {
            $id = (int)$_POST['product_id'];
            $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$id]);
            header("Location: admin_menu.php?msg=deleted");
            exit;
        }
    }

    $categories = $pdo->query("SELECT * FROM categories ORDER BY sort_order")->fetchAll(PDO::FETCH_ASSOC);
    $products = $pdo->query("
        SELECT p.*, c.name as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        ORDER BY c.sort_order, p.id DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ระบบจัดการเมนู - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

    <header class="bg-gray-900 text-white p-4 shadow-md flex justify-between items-center sticky top-0 z-50">
        <h1 class="text-xl font-bold">จัดการเมนู (Menu)</h1>
        
        <div class="space-x-2 flex flex-wrap items-center gap-2">
            <!-- เมนูแสดงตามสิทธิ์ -->
            <?php if ($_SESSION['admin_role'] === 'admin'): ?>
                <a href="admin_dashboard.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-1.5 rounded transition">แดชบอร์ด</a>
            <?php endif; ?>
            
            <a href="admin_orders.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-1.5 rounded transition">KDS</a>
            <a href="admin_menu.php" class="text-sm bg-blue-600 hover:bg-blue-700 px-3 py-1.5 rounded transition">จัดการเมนู</a>
            
            <?php if ($_SESSION['admin_role'] === 'admin'): ?>
                <a href="admin_tables.php" class="text-sm bg-indigo-600 hover:bg-indigo-700 px-3 py-1.5 rounded transition">จัดการโต๊ะ</a>
                <a href="admin_users.php" class="text-sm bg-teal-600 hover:bg-teal-700 px-3 py-1.5 rounded transition">พนักงาน</a>
                <a href="admin_logs.php" class="text-sm bg-purple-600 hover:bg-purple-700 px-3 py-1.5 rounded transition">ดู Logs</a>
            <?php endif; ?>
            
            <a href="logout.php" class="text-sm bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded transition ml-2">ออกจากระบบ</a>
        </div>
    </header>

    <main class="p-6 max-w-6xl mx-auto flex flex-col md:flex-row gap-6">
        
        <div class="md:w-1/3">
            <div class="bg-white p-6 rounded-xl shadow-md sticky top-24">
                <?php if ($_SESSION['admin_role'] === 'admin'): ?>
                    <!-- ฟอร์มเพิ่มเมนู แสดงเฉพาะ Admin -->
                    <h2 class="text-lg font-bold mb-4 border-b pb-2">➕ เพิ่มเมนูใหม่</h2>
                    <form action="admin_menu.php" method="POST" enctype="multipart/form-data" class="space-y-4">
                        <input type="hidden" name="action" value="add">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-1">ชื่อเมนู</label>
                            <input type="text" name="name" required class="w-full border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-1">หมวดหมู่</label>
                            <select name="category_id" required class="w-full border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-1">ราคา (บาท)</label>
                            <input type="number" step="0.01" name="price" required class="w-full border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-1">รูปภาพสินค้า</label>
                            <input type="file" name="image" accept="image/*" required class="w-full border border-gray-300 p-2 rounded-lg bg-gray-50 text-sm">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-1">สถานะเริ่มต้น</label>
                            <select name="status" class="w-full border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option value="available">✅ พร้อมขาย</option>
                                <option value="out_of_stock">❌ สินค้าหมด</option>
                            </select>
                        </div>
                        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition mt-4">บันทึกเมนูใหม่</button>
                    </form>
                <?php else: ?>
                    <!-- ข้อความแสดงสำหรับพนักงานหน้าร้าน -->
                    <div class="text-center py-10">
                        <div class="text-4xl mb-4">🧑‍🍳</div>
                        <h2 class="text-lg font-bold text-gray-800 mb-2">สิทธิ์ของพนักงาน</h2>
                        <p class="text-sm text-gray-500">คุณสามารถปรับเปลี่ยนสถานะ "พร้อมขาย" หรือ "สินค้าหมด" ได้เท่านั้น<br>หากต้องการเพิ่มหรือลบเมนู กรุณาติดต่อผู้จัดการร้าน</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="md:w-2/3">
            <div class="bg-white p-6 rounded-xl shadow-md">
                <h2 class="text-lg font-bold mb-4 border-b pb-2">📋 รายการเมนูทั้งหมด</h2>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 text-gray-600 text-sm border-b">
                                <th class="p-3">รูปภาพ</th>
                                <th class="p-3">ชื่อเมนู</th>
                                <th class="p-3">ราคา</th>
                                <th class="p-3">สถานะ</th>
                                <th class="p-3 text-right">จัดการ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $p): ?>
                                <tr class="border-b hover:bg-gray-50">
                                    <td class="p-3"><img src="<?php echo ltrim(htmlspecialchars($p['image_url']), '/'); ?>" class="w-10 h-10 object-cover rounded shadow-sm"></td>
                                    <td class="p-3 font-semibold text-gray-800"><?php echo htmlspecialchars($p['name']); ?></td>
                                    <td class="p-3 font-bold text-gray-700">฿<?php echo number_format($p['price'], 2); ?></td>
                                    <td class="p-3">
                                        <?php if ($p['status'] == 'available'): ?>
                                            <span class="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-bold">พร้อมขาย</span>
                                        <?php else: ?>
                                            <span class="bg-red-100 text-red-700 px-2 py-1 rounded text-xs font-bold">สินค้าหมด</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3 text-right flex justify-end space-x-2">
                                        <!-- ปุ่มเปลี่ยนสถานะ (กดได้ทุกคน) -->
                                        <form action="admin_menu.php" method="POST" class="inline">
                                            <input type="hidden" name="action" value="toggle_status">
                                            <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                                            <input type="hidden" name="new_status" value="<?php echo $p['status'] == 'available' ? 'out_of_stock' : 'available'; ?>">
                                            <button type="submit" class="text-xs px-2 py-1 rounded border <?php echo $p['status'] == 'available' ? 'border-red-500 text-red-500 hover:bg-red-50' : 'border-green-500 text-green-500 hover:bg-green-50'; ?>">
                                                <?php echo $p['status'] == 'available' ? 'ตั้งว่าหมด' : 'เปิดขาย'; ?>
                                            </button>
                                        </form>
                                        
                                        <!-- ปุ่มลบเมนู (แสดงเฉพาะ Admin) -->
                                        <?php if ($_SESSION['admin_role'] === 'admin'): ?>
                                            <form action="admin_menu.php" method="POST" class="inline" onsubmit="return confirm('คุณแน่ใจหรือไม่ที่จะลบเมนูนี้?');">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                                                <button type="submit" class="text-xs px-2 py-1 rounded bg-gray-200 hover:bg-gray-300 text-gray-700">ลบ</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</body>
</html>