<?php
session_start();

if (empty($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// 👑 ล็อกสิทธิ์: เฉพาะ Super Admin (เจ้าของร้าน) เท่านั้นที่เข้าได้
if ($_SESSION['admin_role'] !== 'superadmin') {
    header("Location: admin_dashboard.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    $current_user_id = $_SESSION['admin_id'];

    // --- ดำเนินการล้างข้อมูลเมื่อมีการ Submit ฟอร์ม ---
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset_data') {
        
        $confirm_text = $_POST['confirm_text'] ?? '';
        
        // เช็กความปลอดภัยด่านสุดท้าย
        if ($confirm_text === 'RESET') {
            try {
                // ปิดการเช็ก Foreign Key ชั่วคราวเพื่อล้างข้อมูลข้ามตาราง
                $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");
                
                // 1. ล้างข้อมูลรายการอาหารในออเดอร์
                $pdo->exec("TRUNCATE TABLE order_items;");
                
                // 2. ล้างข้อมูลประวัติธุรกรรม/สลิป
                $pdo->exec("TRUNCATE TABLE transaction_logs;");
                
                // 3. ล้างข้อมูลออเดอร์ทั้งหมด
                $pdo->exec("TRUNCATE TABLE orders;");
                
                // 4. รีเซ็ตสถานะโต๊ะทุกสาขาให้เป็น 'ว่าง (available)'
                $pdo->exec("UPDATE tables SET status = 'available';");
                
                // เปิดการเช็ก Foreign Key กลับตามเดิม
                $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");

                // บันทึกประวัติว่าใครเป็นคนกด Reset
                $logStmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action_type, description) VALUES (?, 'SYSTEM_RESET', 'ล้างข้อมูลยอดขายและออเดอร์ทั้งหมด (Factory Reset)')");
                $logStmt->execute([$current_user_id]);

                header("Location: admin_reset.php?msg=success");
                exit;

            } catch (PDOException $e) {
                // เผื่อมี Error ตอนรัน SQL
                $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
                die("Error Resetting Data: " . $e->getMessage());
            }
        } else {
            header("Location: admin_reset.php?err=invalid_code");
            exit;
        }
    }

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ล้างข้อมูลระบบ (System Reset) - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // สคริปต์ตรวจสอบการพิมพ์คำว่า RESET
        function checkConfirmText() {
            const input = document.getElementById('confirmInput').value;
            const btn = document.getElementById('resetBtn');
            if (input === 'RESET') {
                btn.disabled = false;
                btn.classList.remove('bg-gray-400', 'cursor-not-allowed');
                btn.classList.add('bg-red-600', 'hover:bg-red-700', 'shadow-lg');
            } else {
                btn.disabled = true;
                btn.classList.add('bg-gray-400', 'cursor-not-allowed');
                btn.classList.remove('bg-red-600', 'hover:bg-red-700', 'shadow-lg');
            }
        }
    </script>
</head>
<body class="bg-gray-100 min-h-screen pb-10">

    <!-- Header Navigation -->
    <header class="bg-gray-900 text-white p-4 shadow-md flex justify-between items-center sticky top-0 z-50 flex-wrap gap-4 border-b-4 border-red-600">
        <div class="flex items-center space-x-4">
            <h1 class="text-xl font-bold">⚠️ Danger Zone: ล้างข้อมูลระบบ</h1>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <a href="admin_dashboard.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">กลับไปแดชบอร์ด</a>
        </div>
    </header>

    <main class="p-6 max-w-3xl mx-auto mt-10">
        
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'success'): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow-sm" role="alert">
                <p class="font-bold">✅ สำเร็จ!</p>
                <p>ระบบได้ล้างข้อมูลออเดอร์ ยอดขาย และประวัติการทำรายการทั้งหมดเรียบร้อยแล้ว (ระบบพร้อมใช้งานใหม่)</p>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['err']) && $_GET['err'] === 'invalid_code'): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded shadow-sm" role="alert">
                <p class="font-bold">❌ ผิดพลาด!</p>
                <p>รหัสยืนยันไม่ถูกต้อง ระบบยังไม่ได้ลบข้อมูลใดๆ</p>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-red-100">
            <div class="bg-red-50 p-6 border-b border-red-100 text-center">
                <div class="w-20 h-20 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                </div>
                <h2 class="text-3xl font-black text-red-600 mb-2">รีเซ็ตยอดขายและออเดอร์</h2>
                <p class="text-gray-600 font-medium">เครื่องมือนี้มักใช้เพื่อเคลียร์ข้อมูลหลังจาก "ทดสอบระบบ" ก่อนเปิดร้านจริง</p>
            </div>

            <div class="p-8">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div class="bg-red-50 p-4 rounded-lg border border-red-200">
                        <h3 class="font-bold text-red-800 border-b border-red-200 pb-2 mb-2 flex items-center">
                            <span class="mr-2">🗑️</span> สิ่งที่จะถูกลบหายไปถาวร
                        </h3>
                        <ul class="text-sm text-red-700 space-y-1 list-disc list-inside">
                            <li>ออเดอร์ลูกค้าทั้งหมด (ทุกสาขา)</li>
                            <li>ประวัติการชำระเงิน / สลิปโอนเงิน</li>
                            <li>ยอดขายรวมในแดชบอร์ด (กลับเป็น 0)</li>
                            <li>บันทึก Transaction Logs ทั้งหมด</li>
                        </ul>
                    </div>
                    
                    <div class="bg-green-50 p-4 rounded-lg border border-green-200">
                        <h3 class="font-bold text-green-800 border-b border-green-200 pb-2 mb-2 flex items-center">
                            <span class="mr-2">🛡️</span> สิ่งที่ระบบจะเก็บรักษาไว้
                        </h3>
                        <ul class="text-sm text-green-700 space-y-1 list-disc list-inside">
                            <li>บัญชีพนักงานและแอดมินทั้งหมด</li>
                            <li>รายชื่อสาขา และคิวอาร์โค้ดโต๊ะ</li>
                            <li>หมวดหมู่ และเมนูอาหารทั้งหมด</li>
                            <li>การตั้งค่าร้านค้า (ชื่อร้าน, พร้อมเพย์)</li>
                        </ul>
                    </div>
                </div>

                <form action="admin_reset.php" method="POST" class="bg-gray-50 p-6 rounded-xl border border-gray-200 text-center" onsubmit="return confirm('🚨 ยืนยันครั้งสุดท้าย! คุณต้องการล้างข้อมูลยอดขายและออเดอร์ทั้งหมดใช่หรือไม่? (การกระทำนี้ไม่สามารถย้อนกลับได้)');">
                    <input type="hidden" name="action" value="reset_data">
                    
                    <label class="block text-gray-700 font-bold mb-3 text-lg">
                        เพื่อป้องกันการกดผิด กรุณาพิมพ์คำว่า <span class="text-red-600 font-black tracking-widest text-xl bg-red-100 px-2 py-1 rounded">RESET</span> ลงในช่องด้านล่าง
                    </label>
                    
                    <input type="text" name="confirm_text" id="confirmInput" onkeyup="checkConfirmText()" placeholder="พิมพ์ RESET ที่นี่..." class="w-full md:w-1/2 mx-auto block border-2 border-gray-300 p-3 rounded-lg focus:ring-4 focus:ring-red-200 focus:border-red-500 text-center text-xl font-bold uppercase mb-4 text-red-600 transition">
                    
                    <button type="submit" id="resetBtn" disabled class="w-full md:w-1/2 mx-auto block bg-gray-400 text-white font-black py-4 rounded-xl cursor-not-allowed transition duration-300">
                        🔥 ยืนยันล้างข้อมูลออเดอร์และยอดขาย
                    </button>
                    <p class="text-xs text-gray-400 mt-3">*ระบบจะบันทึกประวัติว่าคุณ (ID: <?php echo $current_user_id; ?>) เป็นผู้กดล้างข้อมูลนี้</p>
                </form>

            </div>
        </div>
    </main>

</body>
</html>