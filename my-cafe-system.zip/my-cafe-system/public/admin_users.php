<?php
session_start();
if (empty($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
if ($_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
if ($_SESSION['admin_role'] !== 'admin' AND $_SESSION['admin_role'] !== 'superadmin') {
    header("Location: admin_orders.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    $current_user_id = $_SESSION['admin_id'];
    $is_superadmin = ($_SESSION['admin_role'] === 'superadmin');

    // --- ดึงรายชื่อสาขาทั้งหมดมาเตรียมไว้ทำ Dropdown ---
    $branchesList = $pdo->query("SELECT id, name FROM branches ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

    if ($_SERVER['REQUEST_METHOD'] === 'POST' AND isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action === 'add') {
            $username = trim($_POST['username']);
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $role = $_POST['role'];
            $full_name = trim($_POST['full_name']);
            $phone = trim($_POST['phone'] ?? ''); // รับค่าเบอร์โทร
            
            $branch_id = ($role === 'superadmin') ? null : (empty($_POST['branch_id']) ? 1 : (int)$_POST['branch_id']);
            $profile_image = null;

            if (isset($_FILES['profile_image']) AND $_FILES['profile_image']['error'] === 0) {
                $upload_dir = __DIR__ . '/uploads/profiles/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
                $ext = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
                $filename = 'user_' . time() . '_' . rand(100, 999) . '.' . $ext;
                if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_dir . $filename)) {
                    $profile_image = '/uploads/profiles/' . $filename;
                }
            }

            $stmt = $pdo->prepare("INSERT INTO users (username, password, role, full_name, phone, profile_image, branch_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$username, $password, $role, $full_name, $phone, $profile_image, $branch_id]);
            
            $logStmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action_type, description) VALUES (?, 'ADD_USER', ?)");
            $logStmt->execute([$current_user_id, "สร้างบัญชีใหม่: {$username} (ID สาขา: " . ($branch_id ?? 'ทุกสาขา') . ")"]);

            header("Location: admin_users.php?msg=added");
            exit;
        }

        if ($action === 'edit' AND $is_superadmin) {
            $id = (int)$_POST['user_id'];
            $username = trim($_POST['username']);
            $role = $_POST['role'];
            $full_name = trim($_POST['full_name']);
            $phone = trim($_POST['phone'] ?? ''); // รับค่าเบอร์โทร
            
            $branch_id = ($role === 'superadmin') ? null : (empty($_POST['branch_id']) ? 1 : (int)$_POST['branch_id']);
            $profile_image = $_POST['existing_image'] ?? null;

            if (isset($_FILES['profile_image']) AND $_FILES['profile_image']['error'] === 0) {
                $upload_dir = __DIR__ . '/uploads/profiles/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
                $ext = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
                $filename = 'user_' . time() . '_' . rand(100, 999) . '.' . $ext;
                if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_dir . $filename)) {
                    $profile_image = '/uploads/profiles/' . $filename;
                }
            }

            if (!empty($_POST['password'])) {
                $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET username=?, password=?, role=?, full_name=?, phone=?, profile_image=?, branch_id=? WHERE id=?");
                $stmt->execute([$username, $password, $role, $full_name, $phone, $profile_image, $branch_id, $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET username=?, role=?, full_name=?, phone=?, profile_image=?, branch_id=? WHERE id=?");
                $stmt->execute([$username, $role, $full_name, $phone, $profile_image, $branch_id, $id]);
            }

            $logStmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action_type, description) VALUES (?, 'EDIT_USER', ?)");
            $logStmt->execute([$current_user_id, "แก้ไขข้อมูลพนักงาน: {$username}"]);

            header("Location: admin_users.php?msg=updated");
            exit;
        }

        if ($action === 'delete' AND $is_superadmin) {
            $id = (int)$_POST['user_id'];
            if ($id !== $current_user_id) {
                $findStmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                $findStmt->execute([$id]);
                $deleted_user = $findStmt->fetchColumn();

                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$id]);

                $logStmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action_type, description) VALUES (?, 'DELETE_USER', ?)");
                $logStmt->execute([$current_user_id, "ลบบัญชีผู้ใช้: {$deleted_user}"]);
            }
            header("Location: admin_users.php?msg=deleted");
            exit;
        }
    }

    $edit_data = null;
    if (isset($_GET['edit_id']) AND $is_superadmin) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([(int)$_GET['edit_id']]);
        $edit_data = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // อัปเดต SQL ให้ดึง "ชื่อสาขา" ออกมาแสดงด้วย (ใช้ LEFT JOIN)
    $users = $pdo->query("
        SELECT u.*, b.name as branch_name 
        FROM users u 
        LEFT JOIN branches b ON u.branch_id = b.id 
        ORDER BY u.branch_id ASC, u.id ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    $audit_logs = [];
    if ($is_superadmin) {
        $audit_logs = $pdo->query("
            SELECT a.*, u.username as actor_name 
            FROM audit_logs a 
            LEFT JOIN users u ON a.user_id = u.id 
            ORDER BY a.created_at DESC LIMIT 50
        ")->fetchAll(PDO::FETCH_ASSOC);
    }

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>จัดการพนักงาน - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen pb-10">

    <header class="bg-gray-900 text-white p-4 shadow-md flex justify-between items-center sticky top-0 z-50 flex-wrap gap-4">
        <h1 class="text-xl font-bold">Admin: จัดการพนักงาน (Staff Management)</h1>
        <div class="flex flex-wrap items-center gap-2">
            <a href="admin_dashboard.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">แดชบอร์ด</a>
            <a href="admin_orders.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">KDS</a>
            <a href="admin_branches.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการสาขา</a>
            <a href="admin_tables.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการโต๊ะ & QR</a>
            <a href="admin_users.php" class="text-sm bg-teal-600 hover:bg-teal-700 px-3 py-2 rounded font-semibold transition">จัดการพนักงาน</a>
            <a href="admin_logs.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">ดู Logs</a>
            <a href="logout.php" class="text-sm bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded font-semibold transition ml-2">ออก</a>
        </div>
    </header>

    <main class="p-6 max-w-7xl mx-auto flex flex-col md:flex-row gap-6">
        
        <div class="md:w-1/3">
            <div class="bg-white p-6 rounded-xl shadow-md sticky top-24">
                <div class="flex justify-between items-center border-b pb-2 mb-4">
                    <h2 class="text-lg font-bold text-gray-800">
                        <?php echo $edit_data ? '✏️ แก้ไขพนักงาน' : '➕ เพิ่มพนักงาน'; ?>
                    </h2>
                    <?php if ($edit_data): ?>
                        <a href="admin_users.php" class="text-xs bg-gray-200 text-gray-600 px-2 py-1 rounded hover:bg-gray-300">ยกเลิก</a>
                    <?php endif; ?>
                </div>
                
                <form action="admin_users.php" method="POST" enctype="multipart/form-data" class="space-y-4">
                    <input type="hidden" name="action" value="<?php echo $edit_data ? 'edit' : 'add'; ?>">
                    <?php if ($edit_data): ?>
                        <input type="hidden" name="user_id" value="<?php echo $edit_data['id']; ?>">
                        <input type="hidden" name="existing_image" value="<?php echo $edit_data['profile_image']; ?>">
                    <?php endif; ?>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">Username</label>
                        <input type="text" name="username" value="<?php echo $edit_data['username'] ?? ''; ?>" required class="w-full border p-2 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">
                            Password <?php echo $edit_data ? '<span class="text-xs text-red-500">(ว่างถ้าไม่เปลี่ยน)</span>' : ''; ?>
                        </label>
                        <input type="password" name="password" <?php echo $edit_data ? '' : 'required'; ?> class="w-full border p-2 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">ชื่อ-นามสกุล จริง</label>
                        <input type="text" name="full_name" value="<?php echo $edit_data['full_name'] ?? ''; ?>" required class="w-full border p-2 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>

                    <!-- เพิ่มช่องกรอกเบอร์โทรศัพท์ -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">เบอร์โทรศัพท์</label>
                        <input type="text" name="phone" value="<?php echo htmlspecialchars($edit_data['phone'] ?? ''); ?>" class="w-full border p-2 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="เช่น 0812345678">
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-1">ตำแหน่ง</label>
                            <select name="role" id="roleSelect" required class="w-full border p-2 rounded-lg focus:ring-2 focus:ring-blue-500" onchange="toggleBranchInput()">
                                <option value="staff" <?php echo (isset($edit_data['role']) && $edit_data['role'] == 'staff') ? 'selected' : ''; ?>>พนักงาน</option>
                                <option value="manager" <?php echo (isset($edit_data['role']) && $edit_data['role'] == 'manager') ? 'selected' : ''; ?>>ผู้จัดการ</option>
                                <option value="admin" <?php echo (isset($edit_data['role']) && $edit_data['role'] == 'admin') ? 'selected' : ''; ?>>แอดมิน</option>
                                <option value="superadmin" <?php echo (isset($edit_data['role']) && $edit_data['role'] == 'superadmin') ? 'selected' : ''; ?>>เจ้าของร้าน</option>
                            </select>
                        </div>
                        <div id="branchDiv">
                            <label class="block text-sm font-semibold text-gray-700 mb-1">สาขา</label>
                            <!-- เปลี่ยนเป็น Dropdown เลือกสาขา -->
                            <select name="branch_id" id="branchInput" class="w-full border p-2 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <?php foreach ($branchesList as $b): ?>
                                    <option value="<?php echo $b['id']; ?>" <?php echo (isset($edit_data['branch_id']) && $edit_data['branch_id'] == $b['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($b['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">อัปเดตรูปโปรไฟล์</label>
                        <input type="file" name="profile_image" accept="image/*" class="w-full border p-2 rounded-lg bg-gray-50 text-sm">
                    </div>

                    <button type="submit" class="w-full <?php echo $edit_data ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'; ?> text-white font-bold py-3 rounded-lg shadow-sm">
                        <?php echo $edit_data ? '💾 บันทึก' : '➕ สร้างบัญชี'; ?>
                    </button>
                </form>
            </div>
        </div>

        <div class="md:w-2/3 flex flex-col gap-6">
            <div class="bg-white p-6 rounded-xl shadow-md">
                <h2 class="text-lg font-bold mb-4 border-b pb-2 text-gray-800">👥 รายชื่อพนักงาน (แยกตามสาขา)</h2>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 text-gray-600 text-sm border-b">
                                <th class="p-3">สังกัดสาขา</th>
                                <th class="p-3">รูป / ชื่อพนักงาน</th>
                                <!-- เพิ่มหัวตารางเบอร์โทรศัพท์ -->
                                <th class="p-3">เบอร์โทรศัพท์</th>
                                <th class="p-3">ตำแหน่ง</th>
                                <?php if ($is_superadmin): ?>
                                    <th class="p-3 text-right">จัดการ</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $u): ?>
                                <tr class="border-b hover:bg-gray-50">
                                    <td class="p-3">
                                        <?php if ($u['branch_id'] === null): ?>
                                            <span class="bg-gray-800 text-white px-2 py-1 rounded text-xs font-bold">ALL</span>
                                        <?php else: ?>
                                            <span class="bg-indigo-100 text-indigo-700 border border-indigo-200 px-3 py-1 rounded text-xs font-bold">
                                                <?php echo htmlspecialchars($u['branch_name'] ?? 'สาขา ' . $u['branch_id']); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3 flex items-center space-x-3">
                                        <?php if (!empty($u['profile_image'])): ?>
                                            <img src="<?php echo ltrim($u['profile_image'], '/'); ?>" class="w-10 h-10 rounded-full object-cover border">
                                        <?php else: ?>
                                            <div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 font-bold border">👤</div>
                                        <?php endif; ?>
                                        <div>
                                            <div class="font-bold text-gray-800"><?php echo htmlspecialchars($u['full_name'] ?? '-'); ?></div>
                                            <div class="text-xs text-gray-500">@<?php echo htmlspecialchars($u['username']); ?></div>
                                        </div>
                                    </td>
                                    
                                    <!-- เพิ่มการแสดงผลเบอร์โทรศัพท์ในตาราง -->
                                    <td class="p-3 text-sm font-medium text-gray-700">
                                        <?php echo !empty($u['phone']) ? htmlspecialchars($u['phone']) : '<span class="text-gray-400 text-xs italic">ไม่มีข้อมูล</span>'; ?>
                                    </td>

                                    <td class="p-3">
                                        <?php 
                                            if ($u['role'] === 'superadmin') echo '<span class="bg-red-100 text-red-700 px-2 py-1 rounded text-xs font-bold">เจ้าของร้าน</span>';
                                            elseif ($u['role'] === 'admin') echo '<span class="bg-purple-100 text-purple-700 px-2 py-1 rounded text-xs font-bold">แอดมิน</span>';
                                            elseif ($u['role'] === 'manager') echo '<span class="bg-indigo-100 text-indigo-700 px-2 py-1 rounded text-xs font-bold">ผู้จัดการ</span>';
                                            else echo '<span class="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-bold">พนักงาน</span>';
                                        ?>
                                    </td>
                                    <?php if ($is_superadmin): ?>
                                        <td class="p-3 text-right space-x-2 whitespace-nowrap">
                                            <a href="admin_users.php?edit_id=<?php echo $u['id']; ?>" class="text-xs font-bold px-3 py-1.5 rounded bg-yellow-100 text-yellow-700 hover:bg-yellow-200 transition">แก้ไข</a>
                                            <?php if ($u['id'] !== $current_user_id): ?>
                                                <form action="admin_users.php" method="POST" class="inline" onsubmit="return confirm('ยืนยันการลบ?');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                                    <button type="submit" class="text-xs font-bold px-3 py-1.5 rounded bg-red-100 text-red-700 hover:bg-red-200 transition">ลบ</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if ($is_superadmin): ?>
                <div class="bg-white p-6 rounded-xl shadow-md border-t-4 border-indigo-500">
                    <h2 class="text-lg font-bold mb-4 border-b pb-2 text-indigo-800">🕵️ ประวัติการกระทำ (User Audit Logs)</h2>
                    <div class="overflow-x-auto max-h-80 overflow-y-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="bg-indigo-50 text-indigo-800 text-xs border-b sticky top-0">
                                    <th class="p-2">วัน/เวลา</th>
                                    <th class="p-2">ผู้กระทำ</th>
                                    <th class="p-2">ประเภท</th>
                                    <th class="p-2">รายละเอียด</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($audit_logs)): ?>
                                    <tr><td colspan="4" class="p-4 text-center text-gray-500">ยังไม่มีประวัติ</td></tr>
                                <?php else: ?>
                                    <?php foreach ($audit_logs as $log): ?>
                                        <tr class="border-b hover:bg-gray-50 text-sm">
                                            <td class="p-2 text-gray-500 text-xs whitespace-nowrap"><?php echo date('d/m/Y H:i', strtotime($log['created_at'])); ?></td>
                                            <td class="p-2 font-bold text-indigo-600">@<?php echo htmlspecialchars($log['actor_name'] ?? 'System'); ?></td>
                                            <td class="p-2">
                                                <span class="px-2 py-0.5 rounded text-xs font-bold bg-gray-200 text-gray-700">
                                                    <?php echo htmlspecialchars($log['action_type']); ?>
                                                </span>
                                            </td>
                                            <td class="p-2 text-gray-700"><?php echo htmlspecialchars($log['description']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </main>

    <script>
        function toggleBranchInput() {
            var role = document.getElementById('roleSelect').value;
            var branchDiv = document.getElementById('branchDiv');
            if(role === 'superadmin') {
                branchDiv.style.opacity = '0.3';
                branchDiv.style.pointerEvents = 'none';
            } else {
                branchDiv.style.opacity = '1';
                branchDiv.style.pointerEvents = 'auto';
            }
        }
        document.addEventListener('DOMContentLoaded', toggleBranchInput);
    </script>
</body>
</html>