<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt =$pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {$settings[$row['setting_key']] =$row['setting_value'];
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart_data'])) {
        $cart_data = json_decode($_POST['cart_data'], true);
        $payment_method =$_POST['payment_method']; 
        
        $branch_id =$_SESSION['customer_branch_id'] ?? 1; 
        $table_number =$_SESSION['customer_table_id'] ?? 1;  // ค่านี้คือหมายเลขโต๊ะ ไม่ใช่ ID

        // ค้นหา ID ที่แท้จริงของโต๊ะในฐานข้อมูล เพื่อป้องกัน Error 1452
        $findTable =$pdo->prepare("SELECT id FROM tables WHERE branch_id = ? AND table_number = ? LIMIT 1");
        $findTable->execute([$branch_id,$table_number]);
        $table_data =$findTable->fetch(PDO::FETCH_ASSOC);

        if ($table_data) {
            $actual_table_id =$table_data['id'];
        } else {
            // กรณีฉุกเฉิน (หาโต๊ะไม่เจอ) ให้ดึงโต๊ะแรกของสาขามาใช้แทนเพื่อไม่ให้บิลพัง
            $findFallback =$pdo->prepare("SELECT id FROM tables WHERE branch_id = ? LIMIT 1");
            $findFallback->execute([$branch_id]);$fallback = $findFallback->fetch(PDO::FETCH_ASSOC);$actual_table_id = $fallback ? $fallback['id'] : 1;
        }

        if (!empty($cart_data)) {$total_amount = 0;
            foreach ($cart_data as $item) {$total_amount += ($item['price'] *$item['qty']);
            }

            $payment_slip_url = null;
            if ($payment_method === 'qr_promptpay' && isset($_FILES['slip_image']) && $_FILES['slip_image']['error'] === 0) {$upload_dir = __DIR__ . '/uploads/slips/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
                
                $ext = pathinfo($_FILES['slip_image']['name'], PATHINFO_EXTENSION);
                $filename = 'slip_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
                
                if (move_uploaded_file($_FILES['slip_image']['tmp_name'], $upload_dir .$filename)) {
                    $payment_slip_url = '/uploads/slips/' .$filename;
                }
            }

            // บันทึกโดยใช้ $actual_table_id ที่ค้นหามาได้
            $stmt =$pdo->prepare("INSERT INTO orders (queue_number, branch_id, table_id, total_amount, payment_method, payment_slip_url, status) VALUES ('TEMP', ?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([$branch_id, $actual_table_id,$total_amount, $payment_method,$payment_slip_url]);
            $order_id =$pdo->lastInsertId();

            $queue_number = 'Q-' . str_pad($order_id, 3, '0', STR_PAD_LEFT);$pdo->query("UPDATE orders SET queue_number = '$queue_number' WHERE id =$order_id");

            $stmtItem =$pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price_per_unit) VALUES (?, ?, ?, ?)");
            foreach ($cart_data as $item) {$stmtItem->execute([$order_id,$item['id'], $item['qty'],$item['price']]);
            }

            $log_action = ($payment_method == 'qr_promptpay') ? 'slip_uploaded' : 'waiting_for_cash';$pdo->prepare("INSERT INTO transaction_logs (order_id, branch_id, action_type, amount) VALUES (?, ?, ?, ?)")
                ->execute([$order_id,$branch_id, $log_action,$total_amount]);

            header("Location: cart.php?success=1&order_id=" . $order_id . "&q=" . $queue_number);
            exit;
        }
    }

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

$is_success = isset($_GET['success']) &&$_GET['success'] == 1;
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตะกร้าสินค้า - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">

    <header class="text-white p-4 sticky top-0 z-50 shadow-md flex items-center space-x-3" 
            style="background-color: <?php echo htmlspecialchars($settings['primary_color'] ?? '#3b82f6'); ?>;">
        <?php if (!$is_success): ?>
            <a href="menu.php" class="p-1 rounded-full bg-white bg-opacity-20 hover:bg-opacity-30">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
            </a>
        <?php endif; ?>
        <h1 class="text-lg font-bold flex-grow text-center"><?php echo $is_success ? 'สั่งอาหารสำเร็จ' : 'สรุปรายการสั่งซื้อ'; ?></h1>
        <div class="w-8"></div> 
    </header>

    <main class="flex-grow max-w-md mx-auto w-full p-4 pb-24">
        
        <?php if ($is_success): ?>
            <div class="bg-white p-8 rounded-xl shadow-sm text-center space-y-4 mt-8">
                <div class="w-20 h-20 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                </div>
                <h2 class="text-2xl font-bold text-gray-800">ส่งออเดอร์แล้ว!</h2>
                <p class="text-gray-500">หมายเลขคิวของคุณคือ</p>
                <div class="text-4xl font-black text-blue-600 my-2 py-4 border-y-2 border-dashed border-gray-200">
                    <?php echo htmlspecialchars($_GET['q'] ?? ''); ?>
                </div>
                <p class="text-sm font-bold text-gray-700 bg-gray-100 p-2 rounded">
                    📍 โต๊ะ: <?php echo htmlspecialchars($_SESSION['customer_table_name'] ?? 'ไม่ระบุ'); ?>
                </p>
                <p class="text-sm text-gray-500 pb-4">กรุณารอเรียกคิว หรือรอเสิร์ฟที่โต๊ะ</p>
                <a href="menu.php" class="block w-full py-3 rounded-lg font-bold text-white text-center transition-colors"
                   style="background-color: <?php echo htmlspecialchars($settings['primary_color'] ?? '#3b82f6'); ?>;">
                    กลับไปหน้าแรก
                </a>
            </div>
            <script>localStorage.removeItem('my_cafe_cart');</script>

        <?php else: ?>
            <div id="emptyCartMessage" class="hidden text-center mt-12">
                <p class="text-gray-500 mb-4">ยังไม่มีสินค้าในตะกร้า</p>
                <a href="menu.php" class="text-blue-500 font-bold hover:underline">กลับไปเลือกเมนู</a>
            </div>

            <form id="checkoutForm" method="POST" enctype="multipart/form-data" onsubmit="return prepareSubmit(event)" class="bg-white p-5 rounded-xl shadow-sm hidden">
                <div class="flex justify-between items-center mb-4 pb-2 border-b">
                    <h2 class="font-bold text-gray-800">รายการเครื่องดื่ม</h2>
                    <span class="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded border border-blue-200">โต๊ะ: <?php echo htmlspecialchars($_SESSION['customer_table_name'] ?? 'ไม่ระบุ'); ?></span>
                </div>
                <div id="cartItemsContainer" class="space-y-3 mb-6"></div>

                <input type="hidden" name="cart_data" id="cartDataInput">
                
                <div class="flex justify-between items-center mb-4 border-b border-gray-100 pb-4">
                    <span class="text-gray-600 font-bold">ยอดชำระทั้งหมด</span>
                    <span class="text-2xl font-black text-blue-600" id="totalPriceDisplay">฿0.00</span>
                </div>

                <h3 class="font-bold text-gray-700 mb-3 text-sm">เลือกวิธีชำระเงิน</h3>
                <div class="space-y-3 mb-4">
                    <label class="flex items-center p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-blue-50 transition">
                        <input type="radio" name="payment_method" value="qr_promptpay" onchange="togglePaymentSection()" checked class="w-5 h-5 text-blue-600">
                        <span class="ml-3 font-semibold text-gray-700">สแกนจ่าย (QR PromptPay)</span>
                    </label>
                    <label class="flex items-center p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-blue-50 transition">
                        <input type="radio" name="payment_method" value="cash_at_counter" onchange="togglePaymentSection()" class="w-5 h-5 text-blue-600">
                        <span class="ml-3 font-semibold text-gray-700">ชำระเงินสดที่เคาน์เตอร์</span>
                    </label>
                </div>

                <div id="qrUploadSection" class="p-4 bg-gray-50 border border-gray-200 rounded-lg mb-6 text-center">
                    <p class="text-sm font-bold text-gray-700 mb-1">สแกนเพื่อชำระเงิน</p>
                    <p class="text-xs text-gray-500 mb-3">พร้อมเพย์: <?php echo htmlspecialchars($settings['promptpay_no'] ?? '0812345678'); ?></p>
                    
                    <img id="dynamicQrCode" src="" alt="QR Code" class="w-40 h-40 mx-auto bg-white p-2 border rounded-lg shadow-sm mb-3">
                    
                    <p class="text-xs text-red-500 font-bold mb-2">* กรุณาแนบสลิปหลังโอนเงิน</p>
                    <input type="file" name="slip_image" id="slipInput" accept="image/*" class="w-full text-sm border bg-white p-2 rounded-lg cursor-pointer" required>
                </div>

                <button type="submit" class="w-full py-4 rounded-xl font-bold text-white text-lg shadow-lg hover:opacity-90 transition"
                        style="background-color: <?php echo htmlspecialchars($settings['primary_color'] ?? '#3b82f6'); ?>;">
                    ยืนยันการสั่งซื้อ
                </button>
            </form>

            <script>
                let cart = JSON.parse(localStorage.getItem('my_cafe_cart')) || [];
                let currentTotal = 0;
                let promptPayNo = "<?php echo htmlspecialchars($settings['promptpay_no'] ?? '0812345678'); ?>";

                function renderCart() {
                    const container = document.getElementById('cartItemsContainer');
                    const form = document.getElementById('checkoutForm');
                    const emptyMsg = document.getElementById('emptyCartMessage');
                    
                    container.innerHTML = '';
                    currentTotal = 0;

                    if (cart.length === 0) {
                        emptyMsg.classList.remove('hidden');
                        form.classList.add('hidden');
                        return;
                    }

                    emptyMsg.classList.add('hidden');
                    form.classList.remove('hidden');

                    cart.forEach((item, index) => {
                        currentTotal += (item.price * item.qty);
                        container.innerHTML += `
                            <div class="bg-gray-50 p-3 rounded-lg flex justify-between items-center border border-gray-100">
                                <div>
                                    <h3 class="font-bold text-gray-800">${item.name}</h3>
                                    <p class="text-gray-500 text-sm">฿${item.price.toFixed(2)}</p>
                                </div>
                                <div class="flex items-center space-x-3 bg-white border border-gray-200 rounded-lg p-1 shadow-sm">
                                    <button type="button" onclick="changeQty(${index}, -1)" class="w-8 h-8 flex items-center justify-center text-gray-600 font-bold hover:bg-gray-100 rounded">-</button>
                                    <span class="w-4 text-center font-bold text-gray-800">${item.qty}</span>
                                    <button type="button" onclick="changeQty(${index}, 1)" class="w-8 h-8 flex items-center justify-center text-gray-600 font-bold hover:bg-gray-100 rounded">+</button>
                                </div>
                            </div>
                        `;
                    });

                    document.getElementById('totalPriceDisplay').innerText = `฿${currentTotal.toFixed(2)}`;
                    document.getElementById('dynamicQrCode').src = `https://promptpay.io/${promptPayNo}/${currentTotal}.png`;
                }

                function changeQty(index, amount) {
                    cart[index].qty += amount;
                    if (cart[index].qty <= 0) { cart.splice(index, 1); }
                    localStorage.setItem('my_cafe_cart', JSON.stringify(cart));
                    renderCart();
                }

                function togglePaymentSection() {
                    const method = document.querySelector('input[name="payment_method"]:checked').value;
                    const qrSection = document.getElementById('qrUploadSection');
                    const slipInput = document.getElementById('slipInput');
                    if (method === 'qr_promptpay') {
                        qrSection.classList.remove('hidden');
                        slipInput.required = true;
                    } else {
                        qrSection.classList.add('hidden');
                        slipInput.required = false;
                    }
                }

                function prepareSubmit(e) {
                    if (cart.length === 0) { e.preventDefault(); alert('ไม่มีสินค้าในตะกร้า'); return false; }
                    const method = document.querySelector('input[name="payment_method"]:checked').value;
                    if (method === 'qr_promptpay') {
                        if (!document.getElementById('slipInput').value) {
                            e.preventDefault(); alert('กรุณาแนบสลิปการโอนเงินเพื่อยืนยันออเดอร์ครับ'); return false;
                        }
                    }
                    document.getElementById('cartDataInput').value = JSON.stringify(cart);
                    return true;
                }

                renderCart();
                togglePaymentSection(); 
            </script>
        <?php endif; ?>
    </main>
</body>
</html>