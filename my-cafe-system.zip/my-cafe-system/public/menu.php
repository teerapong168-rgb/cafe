<?php
session_start();

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ดึงการตั้งค่าร้าน
    $stmt =$pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {$settings[$row['setting_key']] =$row['setting_value'];
    }

    // สร้างตาราง products หากยังไม่มี
    $pdo->exec("CREATE TABLE IF NOT EXISTS `products` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `name` VARCHAR(100) NOT NULL,
        `price` DECIMAL(10,2) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // เช็กและสร้างคอลัมน์ category และ image_url อัตโนมัติ
    $checkCat =$pdo->query("SHOW COLUMNS FROM products LIKE 'category'")->rowCount();
    if ($checkCat == 0) {$pdo->exec("ALTER TABLE products ADD COLUMN category VARCHAR(50) DEFAULT 'ทั่วไป' AFTER price");
    }
    
    $checkImg =$pdo->query("SHOW COLUMNS FROM products LIKE 'image_url'")->rowCount();
    if ($checkImg == 0) {$pdo->exec("ALTER TABLE products ADD COLUMN image_url TEXT NULL AFTER category");
    }

    // ดึงเมนูอาหารทั้งหมด
    $products =$pdo->query("SELECT * FROM products ORDER BY category ASC, id DESC")->fetchAll(PDO::FETCH_ASSOC);

    // ดึงหมวดหมู่ที่ไม่ซ้ำกันออกมาทำเมนู Tab
    $categories = array_unique(array_column($products, 'category'));
    if (empty($categories)) {$categories = ['ทั่วไป'];
    }

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

$theme_color = htmlspecialchars($settings['primary_color'] ?? '#3b82f6');
$table_name = htmlspecialchars($_SESSION['customer_table_name'] ?? 'ไม่ได้สแกนโต๊ะ');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>เมนูอาหาร - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* ซ่อน Scrollbar สำหรับเมนูหมวดหมู่ */
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        
        /* สไตล์สำหรับรูปภาพเมนู */
        .product-img {
            width: 100%;
            height: 140px;
            object-fit: cover;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen pb-24 font-sans antialiased">

    <!-- Header -->
    <header class="text-white p-4 sticky top-0 z-40 shadow-md transition-colors flex justify-between items-center" 
            style="background-color: <?php echo $theme_color; ?>;">
        <div>
            <h1 class="text-xl font-bold leading-tight"><?php echo htmlspecialchars($settings['shop_name'] ?? 'ชื่อร้าน'); ?></h1>
            <p class="text-xs opacity-90">📍 โต๊ะ: <?php echo $table_name; ?></p>
        </div>
        <div class="bg-white bg-opacity-20 p-2 rounded-full backdrop-blur-sm">
            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
        </div>
    </header>

    <!-- หมวดหมู่สินค้า (Categories Tabs) -->
    <div class="bg-white shadow-sm sticky top-[68px] z-30">
        <div class="flex overflow-x-auto no-scrollbar py-3 px-4 gap-3">
            <button onclick="filterCategory('all')" id="tab-all" class="category-tab whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-bold bg-blue-100 text-blue-700 transition" style="background-color: <?php echo $theme_color; ?>20; color: <?php echo$theme_color; ?>;">
                ทั้งหมด
            </button>
            <?php foreach ($categories as$cat): ?>
                <?php if($cat): ?>
                    <button onclick="filterCategory('<?php echo htmlspecialchars($cat); ?>')" id="tab-<?php echo md5($cat); ?>" class="category-tab whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-bold text-gray-500 bg-gray-100 hover:bg-gray-200 transition">
                        <?php echo htmlspecialchars($cat); ?>
                    </button>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- รายการสินค้า (Product Grid) -->
    <main class="p-4 max-w-2xl mx-auto">
        <?php if (empty($products)): ?>
            <div class="text-center text-gray-400 mt-10">
                <svg class="w-16 h-16 mx-auto mb-3 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                <p>ยังไม่มีเมนูอาหารในระบบ</p>
                <p class="text-xs mt-1">กรุณาแจ้งแอดมินเพิ่มเมนูผ่านระบบหลังบ้าน</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <?php foreach ($products as$p): 
                    $img_src = !empty($p['image_url']) ? htmlspecialchars($p['image_url']) : 'https://placehold.co/400x400/eeeeee/999999?text=' . urlencode($p['name']);
                    $cat_class = 'cat-' . md5($p['category']);
                ?>
                    <div class="product-card <?php echo $cat_class; ?> bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden relative flex flex-col transition transform hover:scale-105 active:scale-95">
                        
                        <div class="relative">
                            <img src="<?php echo $img_src; ?>" alt="<?php echo htmlspecialchars($p['name']); ?>" class="product-img bg-gray-100">
                            <!-- ป้ายราคา -->
                            <div class="absolute bottom-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg shadow-sm">
                                <span class="font-black text-gray-800 text-sm">฿<?php echo number_format($p['price'], 0); ?></span>
                            </div>
                        </div>

                        <div class="p-3 flex-grow flex flex-col justify-between">
                            <h3 class="font-bold text-gray-800 text-sm leading-tight mb-2"><?php echo htmlspecialchars($p['name']); ?></h3>
                            
                            <button onclick="addToCart(<?php echo $p['id']; ?>, '<?php echo htmlspecialchars(addslashes($p['name'])); ?>', <?php echo$p['price']; ?>)" 
                                    class="w-full flex items-center justify-center space-x-1 text-white font-bold py-2 rounded-xl mt-auto shadow-sm"
                                    style="background-color: <?php echo $theme_color; ?>;">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                                <span class="text-xs">เพิ่มลงตะกร้า</span>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <!-- แจ้งเตือน (Toast) เมื่อกดเพิ่มสินค้า -->
    <div id="toast" class="fixed top-20 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white px-4 py-2 rounded-full shadow-lg text-sm font-bold opacity-0 transition-opacity duration-300 pointer-events-none z-50">
        เพิ่มสินค้าแล้ว
    </div>

    <!-- แถบตะกร้าลอย (Floating Cart) -->
    <div id="floatingCart" class="fixed bottom-0 w-full max-w-2xl left-1/2 transform -translate-x-1/2 bg-white border-t p-4 shadow-[0_-10px_40px_rgba(0,0,0,0.1)] transition-transform duration-300 translate-y-full z-50 rounded-t-3xl">
        <div class="flex justify-between items-center mb-3 px-2">
            <div class="flex items-center space-x-3">
                <div class="relative">
                    <svg class="w-8 h-8 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <span id="cartQty" class="absolute -top-1 -right-2 text-xs font-bold text-white bg-red-500 px-1.5 py-0.5 rounded-full border-2 border-white">0</span>
                </div>
                <div class="flex flex-col">
                    <span class="text-xs text-gray-500 font-bold">ยอดรวม</span>
                    <span id="cartTotal" class="text-xl font-black text-gray-800 leading-none">฿0</span>
                </div>
            </div>
            
            <a href="cart.php" class="px-6 py-3 rounded-xl font-bold text-white shadow-lg flex items-center space-x-2"
               style="background-color: <?php echo $theme_color; ?>;">
                <span>ดูตะกร้า</span>
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
            </a>
        </div>
    </div>

    <script>
        let cart = JSON.parse(localStorage.getItem('my_cafe_cart')) || [];
        let themeColor = "<?php echo $theme_color; ?>";

        function addToCart(id, name, price) {
            let item = cart.find(i => i.id === id);
            if (item) {
                item.qty++;
            } else {
                cart.push({ id: id, name: name, price: price, qty: 1 });
            }
            localStorage.setItem('my_cafe_cart', JSON.stringify(cart));
            updateCartUI();
            showToast('เพิ่ม ' + name + ' ลงตะกร้าแล้ว');
        }

        function updateCartUI() {
            let totalQty = cart.reduce((sum, item) => sum + item.qty, 0);
            let totalPrice = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
            
            document.getElementById('cartQty').innerText = totalQty;
            document.getElementById('cartTotal').innerText = '฿' + totalPrice.toFixed(2);
            
            const floatingCart = document.getElementById('floatingCart');
            if (totalQty > 0) {
                floatingCart.classList.remove('translate-y-full');
            } else {
                floatingCart.classList.add('translate-y-full');
            }
        }

        function showToast(message) {
            const toast = document.getElementById('toast');
            toast.innerText = message;
            toast.style.opacity = '1';
            setTimeout(() => { toast.style.opacity = '0'; }, 2000);
        }

        function filterCategory(catHash) {
            // ซ่อน/แสดง เมนู
            document.querySelectorAll('.product-card').forEach(el => {
                if (catHash === 'all') {
                    el.style.display = 'flex';
                } else {
                    if (el.classList.contains('cat-' + md5(catHash))) {
                        el.style.display = 'flex';
                    } else {
                        el.style.display = 'none';
                    }
                }
            });

            // อัปเดตสี Tab ให้ไฮไลท์แท็บที่ถูกเลือก
            document.querySelectorAll('.category-tab').forEach(el => {
                el.className = "category-tab whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-bold text-gray-500 bg-gray-100 hover:bg-gray-200 transition";
                el.style.cssText = ''; 
            });

            let selectedTab = catHash === 'all' ? document.getElementById('tab-all') : document.getElementById('tab-' + md5(catHash));
            if(selectedTab) {
                selectedTab.className = "category-tab whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-bold transition";
                selectedTab.style.backgroundColor = themeColor + '20';
                selectedTab.style.color = themeColor;
            }
        }

        // ฟังก์ชันเข้ารหัส MD5 แบบง่ายๆ สำหรับ JS เพื่อจับคู่กับ PHP
        function md5(string) {
            return string.split('').reduce((a,b)=>{a=((a<<5)-a)+b.charCodeAt(0);return a&a},0).toString(16).replace(/^-/,''); 
        }

        // โหลดข้อมูลตะกร้าทันทีที่เปิดหน้า
        window.addEventListener('DOMContentLoaded', updateCartUI);
    </script>
</body>
</html>