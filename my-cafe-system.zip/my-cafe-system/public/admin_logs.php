<?php
session_start();

// ตรวจสอบการล็อกอิน
if (empty($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
if ($_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// อนุญาตเฉพาะ superadmin, admin และ manager เท่านั้น (พนักงานทั่วไปเข้าไม่ได้)
if ($_SESSION['admin_role'] !== 'superadmin' AND $_SESSION['admin_role'] !== 'admin' AND$_SESSION['admin_role'] !== 'manager') {
    header("Location: admin_orders.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt =$pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {$settings[$row['setting_key']] =$row['setting_value'];
    }

    $current_branch_id =$_SESSION['branch_id'] ?? null;
    
    // กำหนดตัวแปรสำหรับเช็กสิทธิ์หน้า UI
    $is_superadmin = ($_SESSION['admin_role'] === 'superadmin');
    $is_admin_level = in_array($_SESSION['admin_role'], ['superadmin', 'admin']);

    // --- ส่วนที่เพิ่มใหม่: API ดึงข้อมูล Order Items สำหรับแสดงใน Popup ---
    if (isset($_GET['ajax_order_id'])) {
        $order_id = (int)$_GET['ajax_order_id'];
        
        $itemStmt =$pdo->prepare("
            SELECT oi.quantity, oi.price_per_unit, p.name 
            FROM order_items oi 
            JOIN products p ON oi.product_id = p.id 
            WHERE oi.order_id = ?
        ");
        $itemStmt->execute([$order_id]);
        $items =$itemStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // ส่งผลลัพธ์กลับเป็น JSON ให้ JavaScript ไปแสดงผล
        header('Content-Type: application/json');
        echo json_encode($items);
        exit;
    }
    // -------------------------------------------------------------------

    // --- ดึง Log แยกตามสิทธิ์ ---
    if (!$is_admin_level &&$current_branch_id !== null) {
        // สำหรับ Manager: ดูได้เฉพาะสาขาของตัวเอง
        $logsStmt =$pdo->prepare("
            SELECT tl.*, o.queue_number, o.payment_method, o.id as o_id,
                   u.username as emp_user, u.full_name as emp_name, u.role as emp_role, u.profile_image as emp_img, u.phone as emp_phone
            FROM transaction_logs tl
            LEFT JOIN orders o ON tl.order_id = o.id
            LEFT JOIN users u ON tl.user_id = u.id
            WHERE tl.branch_id = ?
            ORDER BY tl.created_at DESC 
            LIMIT 100
        ");
        $logsStmt->execute([$current_branch_id]);
    } else {
        // สำหรับ Admin และ Superadmin: ดูได้ทุกสาขา
        $logsStmt =$pdo->query("
            SELECT tl.*, o.queue_number, o.payment_method, o.id as o_id,
                   u.username as emp_user, u.full_name as emp_name, u.role as emp_role, u.profile_image as emp_img, u.phone as emp_phone
            FROM transaction_logs tl
            LEFT JOIN orders o ON tl.order_id = o.id
            LEFT JOIN users u ON tl.user_id = u.id
            ORDER BY tl.created_at DESC 
            LIMIT 200
        ");
    }
    
    $logs =$logsStmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

function getLogActionLabel($action) {$map = [
        'waiting_for_slip' => '<span class="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-bold">รออัปโหลดสลิป</span>',
        'slip_uploaded'    => '<span class="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs font-bold">ลูกค้ายืนยันสลิป</span>',
        'waiting_for_cash' => '<span class="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-bold">รอชำระเงินสด</span>',
        'order_accepted'   => '<span class="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs font-bold">รับออเดอร์แล้ว</span>',
        'order_finished'   => '<span class="px-2 py-1 bg-yellow-100 text-yellow-700 rounded text-xs font-bold">ทำเสร็จเรียบร้อย</span>',
        'order_delivered'  => '<span class="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-bold">เสิร์ฟ/ส่งมอบแล้ว</span>',
    ];
    return $map[$action] ?? '<span class="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-bold">'.$action.'</span>';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ประวัติ Transaction Logs - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

    <header class="bg-gray-900 text-white p-4 shadow-md flex justify-between items-center sticky top-0 z-50 flex-wrap gap-4">
        <div class="flex items-center space-x-4">
            <h1 class="text-xl font-bold">Admin: ประวัติธุรกรรม (Transaction Logs)</h1>
            <span class="bg-indigo-600 border border-indigo-400 text-xs px-2 py-1 rounded font-bold shadow-sm">
                <?php echo $is_admin_level ? '👑 รวมประวัติทุกสาขา' : '📍 ประวัติเฉพาะสาขา: ' . ($current_branch_id); ?>
            </span>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <!-- เมนูที่ Manager มองเห็นได้ -->
            <a href="admin_dashboard.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">แดชบอร์ด</a>
            <a href="admin_orders.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">KDS</a>
            
            <!-- เมนูเฉพาะ Super Admin -->
            <?php if ($is_superadmin): ?>
                <a href="admin_branches.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition text-yellow-300">จัดการสาขา</a>
                <a href="admin_reset.php" class="text-sm bg-red-800 hover:bg-red-700 text-red-100 px-3 py-2 rounded font-semibold transition shadow-sm border border-red-600">⚠️ ล้างข้อมูลระบบ</a>
            <?php endif; ?>
            
            <!-- เมนูที่เห็นเฉพาะ Admin และ Super Admin -->
            <?php if ($is_admin_level): ?>
                <a href="admin_menu.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการเมนู</a>
                <a href="admin_tables.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการโต๊ะ & QR</a>
                <a href="admin_users.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการพนักงาน</a>
            <?php endif; ?>
            
            <a href="admin_logs.php" class="text-sm bg-teal-600 hover:bg-teal-700 px-3 py-2 rounded font-semibold transition shadow-sm">ดู Logs ธุรกรรม</a>
            <a href="logout.php" class="text-sm bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded font-semibold transition ml-2">ออกจากระบบ</a>
        </div>
    </header>

    <main class="p-6 max-w-6xl mx-auto">
        <div class="bg-white p-6 rounded-xl shadow-sm">
            <h2 class="text-lg font-bold text-gray-800 mb-4 border-b pb-2 flex items-center justify-between">
                <span>📋 ประวัติการเคลื่อนไหว</span>
                <span class="text-xs font-normal text-gray-500 bg-gray-100 px-2 py-1 rounded">💡 กดที่ <span class="font-bold text-blue-600">คิวออเดอร์</span> เพื่อดูรายการอาหาร</span>
            </h2>
            
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-gray-50 text-gray-600 text-sm border-b">
                            <th class="p-3">รหัส Log</th>
                            <?php if ($is_admin_level): ?>
                                <th class="p-3">สาขา</th>
                            <?php endif; ?>
                            <th class="p-3">เวลา</th>
                            <th class="p-3">คิวออเดอร์ (คลิกดู)</th>
                            <th class="p-3">การกระทำ (Action)</th>
                            <th class="p-3">ผู้ดำเนินการ (Staff)</th>
                            <th class="p-3">ยอดเงิน</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($logs)): ?>
                            <tr><td colspan="<?php echo $is_admin_level ? '7' : '6'; ?>" class="p-4 text-center text-gray-500">ยังไม่มีประวัติ Logs</td></tr>
                        <?php else: ?>
                            <?php foreach ($logs as$log): ?>
                                <tr class="border-b hover:bg-gray-50">
                                    <td class="p-3 text-sm text-gray-400">#<?php echo $log['id']; ?></td>
                                    <?php if ($is_admin_level): ?>
                                        <td class="p-3 text-sm font-bold text-indigo-600">สาขา <?php echo htmlspecialchars($log['branch_id']); ?></td>
                                    <?php endif; ?>
                                    <td class="p-3 text-sm text-gray-600"><?php echo date('d/m/Y H:i:s', strtotime($log['created_at'])); ?></td>
                                    
                                    <!-- ปุ่มกดดูรายละเอียดออเดอร์ -->
                                    <td class="p-3">
                                        <?php if ($log['o_id']): ?>
                                            <button onclick="showOrderDetails(<?php echo $log['o_id']; ?>, '<?php echo htmlspecialchars($log['queue_number']); ?>', '<?php echo htmlspecialchars($log['payment_method']); ?>', <?php echo$log['amount']; ?>)" 
                                                    class="font-bold text-blue-600 hover:text-blue-800 hover:underline flex items-center space-x-1 transition">
                                                <span><?php echo htmlspecialchars($log['queue_number']); ?></span>
                                                <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                                            </button>
                                        <?php else: ?>
                                            <span class="text-gray-400">-</span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="p-3"><?php echo getLogActionLabel($log['action_type']); ?></td>
                                    <td class="p-3">
                                        <?php if ($log['emp_user']):$display_name = $log['emp_name'] ?:$log['emp_user'];
                                            $img_src =$log['emp_img'] ? ltrim($log['emp_img'], '/') : 'https://ui-avatars.com/api/?name='.urlencode($display_name).'&background=random';
                                            
                                            if ($log['emp_role'] === 'superadmin') {$role_txt = 'เจ้าของร้าน (Super Admin)';
                                                $role_color = 'bg-red-100 text-red-700';
                                            } elseif ($log['emp_role'] === 'admin') {$role_txt = 'ผู้ดูแลระบบ (Admin)';
                                                $role_color = 'bg-purple-100 text-purple-700';
                                            } elseif ($log['emp_role'] === 'manager') {$role_txt = 'ผู้จัดการสาขา (Manager)';
                                                $role_color = 'bg-indigo-100 text-indigo-700';                                             } else {$role_txt = 'พนักงาน (Staff)';
                                                $role_color = 'bg-blue-100 text-blue-700';
                                            }
                                            
                                            $phone =$log['emp_phone'] ?: 'ไม่ได้ระบุเบอร์โทร';
                                        ?>
                                            <button onclick="showProfileCard('<?php echo htmlspecialchars($display_name); ?>', '<?php echo htmlspecialchars($role_txt); ?>', '<?php echo htmlspecialchars($phone); ?>', '<?php echo $img_src; ?>', '<?php echo$role_color; ?>')" 
                                                    class="text-sm font-bold text-gray-700 bg-gray-50 hover:bg-gray-100 border border-gray-200 px-3 py-1.5 rounded-full flex items-center space-x-2 transition shadow-sm">
                                                <img src="<?php echo $img_src; ?>" class="w-5 h-5 rounded-full object-cover">
                                                <span><?php echo htmlspecialchars($display_name); ?></span>
                                            </button>
                                        <?php else: ?>
                                            <span class="text-sm text-gray-500 bg-gray-50 border px-3 py-1.5 rounded-full flex items-center space-x-2 w-max">
                                                <span>📱</span><span>ลูกค้า (ระบบ)</span>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3 font-bold text-gray-800">฿<?php echo number_format($log['amount'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Modal นามบัตรพนักงาน -->
    <div id="profileModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center backdrop-blur-sm">
        <div class="bg-white rounded-2xl shadow-2xl overflow-hidden max-w-sm w-full relative transform transition-all">
            <button onclick="closeProfileCard()" class="absolute top-3 right-4 text-white hover:text-gray-200 text-3xl font-black z-10">&times;</button>
            <div class="h-24 bg-gradient-to-r from-blue-600 to-indigo-700 w-full relative"></div>
            <div class="flex justify-center -mt-12 relative z-10">
                <img id="modalImg" src="" class="w-24 h-24 rounded-full border-4 border-white object-cover shadow-lg bg-white">
            </div>
            <div class="text-center p-6 pt-2">
                <h2 id="modalName" class="text-2xl font-black text-gray-800 mb-1">ชื่อพนักงาน</h2>
                <span id="modalRole" class="inline-block px-3 py-1 rounded-full text-xs font-bold mb-4">ตำแหน่ง</span>
                <div class="bg-gray-50 rounded-lg p-4 border border-gray-100 flex items-center justify-center space-x-3 mt-2">
                    <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                    <span id="modalPhone" class="font-bold text-gray-700">เบอร์โทร</span>
                </div>
            </div>
            <div class="bg-gray-100 px-6 py-3 border-t text-center">
                <button onclick="closeProfileCard()" class="text-sm font-bold text-gray-500 hover:text-gray-800">ปิดหน้าต่าง</button>
            </div>
        </div>
    </div>

    <!-- Modal รายละเอียดออเดอร์ (เพิ่มใหม่) -->
    <div id="orderModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center backdrop-blur-sm">
        <div class="bg-white rounded-2xl shadow-2xl overflow-hidden max-w-md w-full relative transform transition-all flex flex-col max-h-[90vh]">
            <div class="bg-blue-600 p-4 flex justify-between items-center text-white sticky top-0 z-10">
                <div>
                    <h2 class="text-lg font-bold">บิลรายการอาหาร</h2>
                    <p id="modalOrderQ" class="text-sm opacity-90 font-medium">คิว: Q-000</p>
                </div>
                <button onclick="closeOrderModal()" class="text-white hover:text-gray-200 text-3xl font-black">&times;</button>
            </div>
            
            <div class="p-6 overflow-y-auto flex-grow bg-gray-50">
                <div class="flex justify-between items-center border-b pb-3 mb-3">
                    <span class="text-sm text-gray-500 font-bold">วิธีชำระเงิน:</span>
                    <span id="modalOrderPayment" class="text-sm font-bold text-gray-800 bg-gray-200 px-2 py-1 rounded">เงินสด</span>
                </div>
                
                <!-- พื้นที่แสดงรายการอาหาร -->
                <ul id="modalOrderItemsList" class="space-y-3 mb-4">
                    <!-- รายการอาหารจะถูกโหลดมาใส่ตรงนี้ด้วย JS -->
                    <li class="text-center text-gray-400 py-4">กำลังโหลดข้อมูล...</li>
                </ul>
            </div>
            
            <div class="bg-white p-4 border-t sticky bottom-0">
                <div class="flex justify-between items-center">
                    <span class="text-gray-600 font-bold">ยอดรวมสุทธิ</span>
                    <span id="modalOrderTotal" class="text-2xl font-black text-blue-600">฿0.00</span>
                </div>
            </div>
        </div>
    </div>

    <script>
        // ฟังก์ชันนามบัตร
        function showProfileCard(name, role, phone, imgUrl, roleColorClass) {
            document.getElementById('modalName').innerText = name;
            document.getElementById('modalRole').innerText = role;
            document.getElementById('modalPhone').innerText = phone;
            document.getElementById('modalImg').src = imgUrl;
            document.getElementById('modalRole').className = "inline-block px-3 py-1 rounded-full text-xs font-bold mb-4 " + roleColorClass;
            document.getElementById('profileModal').classList.remove('hidden');
        }
        function closeProfileCard() {
            document.getElementById('profileModal').classList.add('hidden');
        }

        // ฟังก์ชันแสดงรายการออเดอร์
        function showOrderDetails(orderId, qNum, paymentMethod, totalAmount) {
            // เซ็ตข้อมูลเบื้องต้น
            document.getElementById('modalOrderQ').innerText = 'คิว: ' + qNum;
            document.getElementById('modalOrderPayment').innerText = (paymentMethod === 'qr_promptpay') ? '📱 สแกนจ่าย' : '💵 เงินสด';
            document.getElementById('modalOrderTotal').innerText = '฿' + parseFloat(totalAmount).toFixed(2);
            
            const listContainer = document.getElementById('modalOrderItemsList');
            listContainer.innerHTML = '<li class="text-center text-gray-400 py-4">กำลังโหลดข้อมูล...</li>';
            
            // เปิดหน้าต่าง Modal
            document.getElementById('orderModal').classList.remove('hidden');

            // ใช้ Fetch API เพื่อดึงข้อมูลสินค้าจาก PHP
            fetch('admin_logs.php?ajax_order_id=' + orderId)
                .then(response => response.json())
                .then(data => {
                    listContainer.innerHTML = ''; // ล้างข้อความกำลังโหลด
                    
                    if(data.length === 0) {
                        listContainer.innerHTML = '<li class="text-center text-gray-400 py-4">ไม่พบรายการอาหารในระบบ</li>';
                        return;
                    }

                    // วนลูปสร้างรายการอาหาร
                    data.forEach(item => {
                        let totalItemPrice = parseFloat(item.quantity) * parseFloat(item.price_per_unit);
                        let li = document.createElement('li');
                        li.className = "flex justify-between items-start border-b border-dashed border-gray-300 pb-2";
                        li.innerHTML = `
                            <div class="flex-grow pr-4">
                                <span class="font-bold text-gray-800 block">${item.name}</span>
                                <span class="text-xs text-gray-500">฿${parseFloat(item.price_per_unit).toFixed(2)} / ชิ้น</span>
                            </div>
                            <div class="text-right flex-shrink-0">
                                <span class="font-bold text-blue-600 block">x${item.quantity}</span>
                                <span class="text-sm font-bold text-gray-800">฿${totalItemPrice.toFixed(2)}</span>
                            </div>
                        `;
                        listContainer.appendChild(li);
                    });
                })
                .catch(error => {
                    console.error('Error fetching order items:', error);
                    listContainer.innerHTML = '<li class="text-center text-red-500 py-4">เกิดข้อผิดพลาดในการโหลดข้อมูล</li>';
                });
        }
        
        function closeOrderModal() {
            document.getElementById('orderModal').classList.add('hidden');
        }
    </script>
</body>
</html>