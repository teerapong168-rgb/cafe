<?php
session_start();

if (empty($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
if ($_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
if ($_SESSION['admin_role'] !== 'admin' AND$_SESSION['admin_role'] !== 'superadmin') {
    header("Location: admin_orders.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt =$pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {$settings[$row['setting_key']] =$row['setting_value'];
    }

    $current_branch_id =$_SESSION['branch_id'] ?? null;
    $is_superadmin = ($_SESSION['admin_role'] === 'superadmin');

    // ดึงรายชื่อสาขามาเตรียมทำ Dropdown
    $branchesList =$pdo->query("SELECT id, name FROM branches ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

    // เช็กและสร้างคอลัมน์อัตโนมัติ
    $checkCol =$pdo->query("SHOW COLUMNS FROM tables LIKE 'branch_id'")->rowCount();
    if ($checkCol == 0) {$pdo->exec("ALTER TABLE tables ADD COLUMN branch_id INT NOT NULL DEFAULT 1 AFTER id");
    }
    
    $checkStatus =$pdo->query("SHOW COLUMNS FROM tables LIKE 'status'")->rowCount();
    if ($checkStatus == 0) {$pdo->exec("ALTER TABLE tables ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'available'");
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' AND isset($_POST['action'])) {
        $action =$_POST['action'];

        if ($action === 'add') {
            $table_number = (int)$_POST['table_number'];
            $branch_id =$is_superadmin ? (int)$_POST['branch_id'] :$current_branch_id;
            
            $checkStmt =$pdo->prepare("SELECT id FROM tables WHERE table_number = ? AND branch_id = ?");
            $checkStmt->execute([$table_number,$branch_id]);
            
            if ($checkStmt->rowCount() == 0) {
                try {
                    // --- ส่วนที่แก้ไข: สร้าง qr_token แบบสุ่มเพื่อป้องกัน Error 1062 ---
                    $qr_token = uniqid('qr_') . bin2hex(random_bytes(4));
                    
                    $insertStmt =$pdo->prepare("INSERT INTO tables (table_number, branch_id, status, qr_token) VALUES (?, ?, 'available', ?)");
                    $insertStmt->execute([$table_number, $branch_id,$qr_token]);
                    header("Location: admin_tables.php?msg=added");
                    exit;
                } catch (PDOException $e) {
                    die("Error: " . $e->getMessage());
                }
            } else {
                header("Location: admin_tables.php?err=duplicate");
                exit;
            }
        }

        if ($action === 'delete') {
            $id = (int)$_POST['table_id'];
            try {
                if ($is_superadmin) {
                    $delStmt =$pdo->prepare("DELETE FROM tables WHERE id = ?");
                    $delStmt->execute([$id]);
                } else {
                    $delStmt =$pdo->prepare("DELETE FROM tables WHERE id = ? AND branch_id = ?");
                    $delStmt->execute([$id,$current_branch_id]);
                }
                header("Location: admin_tables.php?msg=deleted");
                exit;
            } catch (PDOException $e) {
                if ($e->getCode() == 23000) {
                    header("Location: admin_tables.php?err=in_use");
                    exit;
                } else {
                    die("Error: " . $e->getMessage());
                }
            }
        }
    }

    // ดึงข้อมูลโต๊ะ และใช้ JOIN ดึงชื่อสาขามาแสดง
    if ($is_superadmin) {
        $tables =$pdo->query("
            SELECT t.*, b.name as branch_name 
            FROM tables t 
            LEFT JOIN branches b ON t.branch_id = b.id 
            ORDER BY t.branch_id ASC, t.table_number ASC
        ")->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $tablesStmt =$pdo->prepare("
            SELECT t.*, b.name as branch_name 
            FROM tables t 
            LEFT JOIN branches b ON t.branch_id = b.id 
            WHERE t.branch_id = ? 
            ORDER BY t.table_number ASC
        ");
        $tablesStmt->execute([$current_branch_id]);
        $tables =$tablesStmt->fetchAll(PDO::FETCH_ASSOC);
    }

    $protocol = (isset($_SERVER['HTTPS']) AND$_SERVER['HTTPS'] === 'on') ? "https" : "http";
    $base_url =$protocol . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>จัดการโต๊ะและ QR - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        function printQRCode(divId, tableName, branchName) {
            let printContents = document.getElementById(divId).innerHTML;
            let originalContents = document.body.innerHTML;
            
            let printWindow = `
                <div style="text-align:center; padding: 20px; font-family: sans-serif;">
                    <h2 style="margin-bottom: 5px; font-size: 24px;">${tableName}</h2>
                    <p style="margin-top: 0; color: #666;">${branchName}</p>
                    <div style="margin: 20px auto; width: 250px;">${printContents}</div>
                    <p style="font-size: 14px; font-weight: bold;">สแกนเพื่อสั่งอาหาร / Scan to order</p>
                </div>
            `;
            
            document.body.innerHTML = printWindow;
            window.print();
            document.body.innerHTML = originalContents;
            window.location.reload(); 
        }
    </script>
</head>
<body class="bg-gray-100 min-h-screen pb-10">

    <header class="bg-gray-900 text-white p-4 shadow-md flex justify-between items-center sticky top-0 z-50 flex-wrap gap-4">
        <div class="flex items-center space-x-4">
            <h1 class="text-xl font-bold">Admin: จัดการโต๊ะ (Tables & QR)</h1>
            <span class="bg-indigo-600 border border-indigo-400 text-xs px-2 py-1 rounded font-bold shadow-sm">
                <?php echo $current_branch_id ? '📍 สาขา ID: ' . $current_branch_id : '👑 ควบคุมโต๊ะทุกสาขา'; ?>
            </span>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <a href="admin_dashboard.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">แดชบอร์ด</a>
            <a href="admin_orders.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">KDS</a>
            <a href="admin_branches.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการสาขา</a>
            <a href="admin_tables.php" class="text-sm bg-teal-600 hover:bg-teal-700 px-3 py-2 rounded font-semibold transition">จัดการโต๊ะ & QR</a>
            <a href="admin_users.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการพนักงาน</a>
            <a href="logout.php" class="text-sm bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded font-semibold transition ml-2">ออกจากระบบ</a>
        </div>
    </header>

    <main class="p-6 max-w-7xl mx-auto flex flex-col md:flex-row gap-6">
        
        <div class="md:w-1/3">
            <div class="bg-white p-6 rounded-xl shadow-md sticky top-24">
                <h2 class="text-lg font-bold mb-4 border-b pb-2 text-gray-800">➕ เพิ่มโต๊ะใหม่</h2>
                
                <?php if (isset($_GET['err']) AND$_GET['err'] == 'duplicate'): ?>
                    <div class="bg-red-100 text-red-700 p-3 rounded text-sm mb-4 font-bold text-center">❌ เบอร์โต๊ะนี้มีอยู่ในสาขานี้แล้ว!</div>
                <?php endif; ?>
                <?php if (isset($_GET['err']) AND$_GET['err'] == 'in_use'): ?>
                    <div class="bg-yellow-100 text-yellow-800 border border-yellow-300 p-3 rounded text-sm mb-4 font-bold text-center">
                        ⚠️ ไม่สามารถลบโต๊ะนี้ได้<br>เนื่องจากมีประวัติยอดขายของโต๊ะนี้อยู่
                    </div>
                <?php endif; ?>

                <form action="admin_tables.php" method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="add">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">หมายเลขโต๊ะ</label>
                        <input type="number" name="table_number" min="1" required class="w-full border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-indigo-500" placeholder="เช่น 1, 2, 3...">
                    </div>
                    <?php if ($is_superadmin): ?>
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-1">เพิ่มเข้าสาขา</label>
                            <select name="branch_id" class="w-full border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-indigo-500">
                                <?php foreach ($branchesList as$b): ?>
                                    <option value="<?php echo $b['id']; ?>"><?php echo htmlspecialchars($b['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-lg transition mt-4 shadow-sm">
                        บันทึกโต๊ะ & สร้าง QR Code
                    </button>
                </form>
            </div>
        </div>

        <div class="md:w-2/3">
            <div class="bg-white p-6 rounded-xl shadow-md">
                <h2 class="text-lg font-bold mb-4 border-b pb-2 text-gray-800">🪑 โต๊ะและคิวอาร์โค้ดสั่งอาหาร</h2>
                
                <?php if (empty($tables)): ?>
                    <div class="text-center text-gray-500 py-10">ยังไม่มีข้อมูลโต๊ะ กรุณาเพิ่มโต๊ะใหม่</div>
                <?php else: ?>
                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
                        <?php foreach ($tables as $t):$order_url = $base_url . "/index.php?branch_id=" . $t['branch_id'] . "&table_id=" . $t['table_number'];$qr_url = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" . urlencode($order_url);$branch_name_display = htmlspecialchars($t['branch_name'] ?? 'สาขา ' . $t['branch_id']);
                        ?>
                            <div class="border rounded-xl p-4 flex flex-col items-center justify-between shadow-sm hover:shadow-md transition bg-gray-50 relative group">
                                <?php if ($is_superadmin): ?>
                                    <span class="absolute top-2 left-2 bg-indigo-100 text-indigo-700 text-[10px] font-black px-2 py-0.5 rounded shadow-sm">
                                        <?php echo $branch_name_display; ?>
                                    </span>
                                <?php endif; ?>
                                
                                <div id="qr-table-<?php echo $t['id']; ?>" class="w-full mt-4">
                                    <img src="<?php echo $qr_url; ?>" alt="QR โต๊ะ <?php echo $t['table_number']; ?>" class="w-full aspect-square object-contain bg-white rounded p-1 border">
                                </div>
                                <div class="text-center mt-3 mb-2 w-full">
                                    <h3 class="text-xl font-black text-gray-800">โต๊ะ T-<?php echo str_pad($t['table_number'], 2, '0', STR_PAD_LEFT); ?></h3>
                                </div>
                                <div class="w-full flex space-x-2 mt-auto">
                                    <button type="button" onclick="printQRCode('qr-table-<?php echo $t['id']; ?>', 'โต๊ะ T-<?php echo str_pad($t['table_number'], 2, '0', STR_PAD_LEFT); ?>', '<?php echo$branch_name_display; ?>')" class="flex-1 bg-gray-800 hover:bg-gray-900 text-white text-xs font-bold py-2 rounded transition text-center">
                                        🖨️ พรินต์
                                    </button>
                                    <form action="admin_tables.php" method="POST" class="flex-1" onsubmit="return confirm('ลบโต๊ะเบอร์ <?php echo $t['table_number']; ?> ใช่หรือไม่?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="table_id" value="<?php echo $t['id']; ?>">
                                        <button type="submit" class="w-full bg-red-100 text-red-600 hover:bg-red-200 text-xs font-bold py-2 rounded transition">
                                            ลบโต๊ะ
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

</body>
</html>