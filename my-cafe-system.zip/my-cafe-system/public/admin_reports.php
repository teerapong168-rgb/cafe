<?php
session_start();

// ตรวจสอบสิทธิ์การล็อกอิน
if (empty($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// อนุญาตเฉพาะ superadmin, admin และ manager เท่านั้น (บล็อก staff)
if (!in_array($_SESSION['admin_role'], ['superadmin', 'admin', 'manager'])) {
    header("Location: admin_orders.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    $current_branch_id = $_SESSION['branch_id'] ?? null;
    
    // กำหนดตัวแปรเช็กสิทธิ์
    $is_superadmin = ($_SESSION['admin_role'] === 'superadmin');
    $is_admin_level = in_array($_SESSION['admin_role'], ['superadmin', 'admin']);

    // --- ระบบรับค่าตัวกรอง (Filter) ---
    // กำหนดวันที่เริ่มต้น (ค่าเริ่มต้นคือวันที่ 1 ของเดือนนี้) และวันสิ้นสุด (วันนี้)
    $start_date = $_GET['start_date'] ?? date('Y-m-01');
    $end_date = $_GET['end_date'] ?? date('Y-m-d');
    
    $filter_branch = null;
    $branchesList = [];

    if ($is_admin_level) {
        // แอดมินดึงรายชื่อสาขาทั้งหมดมาทำ Dropdown
        $branchesList = $pdo->query("SELECT id, name FROM branches ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($_GET['filter_branch'])) {
            $filter_branch = (int)$_GET['filter_branch'];
        }
    } else {
        // ผู้จัดการถูกบังคับให้ดูเฉพาะสาขาตัวเอง
        $filter_branch = $current_branch_id;
    }

    // --- สร้างเงื่อนไข SQL (Where Clause) ---
    // ใช้สถานะ completed เพื่อคำนวณยอดขายที่รับเงินแล้ว หรือสถานะที่ไม่ได้ถูกยกเลิก (voided)
    $where_sql = "DATE(o.created_at) BETWEEN ? AND ? AND o.status != 'voided'";
    $params = [$start_date, $end_date];

    if ($filter_branch !== null) {
        $where_sql .= " AND o.branch_id = ?";
        $params[] = $filter_branch;
    }

    // 1. ดึงสรุปยอดขายรวมและจำนวนออเดอร์
    $statsStmt = $pdo->prepare("SELECT COUNT(o.id) as total_orders, SUM(o.total_amount) as total_sales FROM orders o WHERE $where_sql");
    $statsStmt->execute($params);
    $statsData = $statsStmt->fetch(PDO::FETCH_ASSOC);
    $total_sales = $statsData['total_sales'] ?? 0;
    $total_orders = $statsData['total_orders'] ?? 0;

    // 2. ดึง 10 อันดับเมนูขายดีในช่วงเวลานี้
    $topProductsStmt = $pdo->prepare("
        SELECT p.name, SUM(oi.quantity) as total_qty, SUM(oi.quantity * oi.price_per_unit) as total_revenue
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        JOIN products p ON oi.product_id = p.id
        WHERE $where_sql
        GROUP BY p.id
        ORDER BY total_qty DESC
        LIMIT 10
    ");
    $topProductsStmt->execute($params);
    $topProducts = $topProductsStmt->fetchAll(PDO::FETCH_ASSOC);

    // 3. ดึงประวัติออเดอร์ที่เกิดขึ้นในช่วงเวลานี้
    $historyStmt = $pdo->prepare("
        SELECT o.*, b.name as branch_name, t.table_number
        FROM orders o
        LEFT JOIN branches b ON o.branch_id = b.id
        LEFT JOIN tables t ON o.table_id = t.id
        WHERE $where_sql
        ORDER BY o.created_at DESC
    ");
    $historyStmt->execute($params);
    $historyOrders = $historyStmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายงานยอดขาย (Sales Report) - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen pb-10">

    <header class="bg-gray-900 text-white p-4 shadow-md flex justify-between items-center sticky top-0 z-50 flex-wrap gap-4">
        <div class="flex items-center space-x-4">
            <h1 class="text-xl font-bold">📈 รายงานยอดขาย</h1>
            <span class="bg-indigo-600 border border-indigo-400 text-xs px-2 py-1 rounded font-bold shadow-sm">
                <?php echo $is_admin_level ? '👑 ระดับบริหาร (Admin/Owner)' : '📍 ผู้จัดการสาขา: ' . ($current_branch_id); ?>
            </span>
        </div>
        
        <div class="flex flex-wrap items-center gap-2">
            <a href="admin_dashboard.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition shadow-sm">แดชบอร์ด</a>
            <a href="admin_orders.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">KDS (รับออเดอร์)</a>
            <a href="admin_reports.php" class="text-sm bg-blue-600 hover:bg-blue-700 px-3 py-2 rounded font-semibold transition shadow-sm">รายงานยอดขาย</a>
            
            <?php if ($is_superadmin): ?>
                <a href="admin_branches.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition text-yellow-300">จัดการสาขา</a>
                <a href="admin_reset.php" class="text-sm bg-red-800 hover:bg-red-700 text-red-100 px-3 py-2 rounded font-semibold transition shadow-sm border border-red-600">⚠️ ล้างข้อมูล</a>
            <?php endif; ?>
            
            <?php if ($is_admin_level): ?>
                <a href="admin_menu.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการเมนู</a>
                <a href="admin_tables.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการโต๊ะ & QR</a>
                <a href="admin_users.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">จัดการพนักงาน</a>
            <?php endif; ?>
            
            <a href="admin_logs.php" class="text-sm bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded font-semibold transition">ดู Logs</a>
            <a href="logout.php" class="text-sm bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded font-semibold transition ml-2">ออกจากระบบ</a>
        </div>
    </header>

    <main class="p-6 max-w-7xl mx-auto space-y-6">
        
        <!-- ตัวกรองข้อมูล (Filter) -->
        <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <form method="GET" action="admin_reports.php" class="flex flex-wrap items-end gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">ตั้งแต่วันที่</label>
                    <input type="date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>" class="border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-blue-500 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">ถึงวันที่</label>
                    <input type="date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>" class="border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-blue-500 text-sm">
                </div>
                
                <?php if ($is_admin_level): ?>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">เลือกสาขา</label>
                        <select name="filter_branch" class="border border-gray-300 p-2 rounded-lg focus:ring-2 focus:ring-blue-500 text-sm">
                            <option value="">รวมทุกสาขา</option>
                            <?php foreach ($branchesList as $b): ?>
                                <option value="<?php echo $b['id']; ?>" <?php echo ($filter_branch == $b['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($b['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>

                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded-lg transition shadow-sm h-10">
                    🔍 ค้นหา
                </button>
            </form>
        </div>

        <!-- สรุปตัวเลขยอดขาย -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-gradient-to-r from-blue-500 to-indigo-600 p-6 rounded-xl shadow-md text-white">
                <p class="text-blue-100 text-sm font-semibold mb-1">ยอดขายสุทธิ (ช่วงเวลาที่เลือก)</p>
                <h3 class="text-4xl font-black">฿<?php echo number_format($total_sales, 2); ?></h3>
            </div>
            <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <p class="text-gray-500 text-sm font-semibold mb-1">จำนวนบิล/ออเดอร์</p>
                <h3 class="text-4xl font-black text-gray-800"><?php echo number_format($total_orders); ?> <span class="text-lg text-gray-400 font-normal">บิล</span></h3>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- จัดอันดับสินค้าขายดี -->
            <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <h2 class="text-lg font-bold mb-4 border-b pb-2 text-gray-800">🏆 10 อันดับเมนูขายดี</h2>
                <div class="space-y-3">
                    <?php if (empty($topProducts)): ?>
                        <p class="text-center text-gray-500 py-4 text-sm">ไม่มีข้อมูลการขายในช่วงเวลานี้</p>
                    <?php else: ?>
                        <?php foreach ($topProducts as $index => $top): ?>
                            <div class="flex items-center space-x-3 bg-gray-50 p-2 rounded-lg border border-gray-100">
                                <div class="w-8 h-8 flex-shrink-0 <?php echo $index < 3 ? 'bg-yellow-100 text-yellow-600' : 'bg-gray-200 text-gray-600'; ?> font-bold rounded-full flex items-center justify-center text-sm">
                                    #<?php echo $index + 1; ?>
                                </div>
                                <div class="flex-grow">
                                    <h3 class="font-bold text-sm text-gray-800"><?php echo htmlspecialchars($top['name']); ?></h3>
                                    <p class="text-xs text-gray-500">ขายได้ <span class="font-bold text-green-600"><?php echo $top['total_qty']; ?></span> ชิ้น</p>
                                </div>
                                <div class="text-right text-sm font-bold text-indigo-600">
                                    ฿<?php echo number_format($top['total_revenue'], 2); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- ตารางออเดอร์ล่าสุด -->
            <div class="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <h2 class="text-lg font-bold mb-4 border-b pb-2 text-gray-800">📋 รายการบิลออเดอร์</h2>
                <div class="overflow-x-auto max-h-96 overflow-y-auto">
                    <table class="w-full text-left border-collapse relative">
                        <thead class="bg-white sticky top-0 shadow-sm">
                            <tr class="text-gray-600 text-sm border-b">
                                <th class="p-3 bg-gray-50">เวลาทำรายการ</th>
                                <th class="p-3 bg-gray-50">เลขคิว</th>
                                <?php if ($is_admin_level): ?>
                                    <th class="p-3 bg-gray-50">สาขา</th>
                                <?php endif; ?>
                                <th class="p-3 bg-gray-50">วิธีชำระ</th>
                                <th class="p-3 bg-gray-50 text-right">ยอดรวม</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($historyOrders)): ?>
                                <tr><td colspan="<?php echo $is_admin_level ? '5' : '4'; ?>" class="p-4 text-center text-gray-500 text-sm">ไม่มีประวัติออเดอร์</td></tr>
                            <?php else: ?>
                                <?php foreach ($historyOrders as $ord): ?>
                                    <tr class="border-b hover:bg-gray-50 text-sm">
                                        <td class="p-3 text-gray-600"><?php echo date('d/m/Y H:i', strtotime($ord['created_at'])); ?></td>
                                        <td class="p-3 font-bold text-blue-600">
                                            <?php echo htmlspecialchars($ord['queue_number']); ?>
                                            <span class="block text-xs text-gray-400 font-normal mt-0.5">โต๊ะ: T-<?php echo $ord['table_number'] ? str_pad($ord['table_number'], 2, '0', STR_PAD_LEFT) : '--'; ?></span>
                                        </td>
                                        <?php if ($is_admin_level): ?>
                                            <td class="p-3 font-medium text-gray-700"><?php echo htmlspecialchars($ord['branch_name'] ?? 'สาขา '.$ord['branch_id']); ?></td>
                                        <?php endif; ?>
                                        <td class="p-3 text-gray-600">
                                            <?php echo $ord['payment_method'] == 'qr_promptpay' ? '📱 สแกนจ่าย' : '💵 เงินสด'; ?>
                                        </td>
                                        <td class="p-3 font-bold text-gray-800 text-right">฿<?php echo number_format($ord['total_amount'], 2); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </main>

</body>
</html>