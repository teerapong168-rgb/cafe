<?php
// 1. เปิดใช้งาน Session เป็นบรรทัดแรกสุด (สำคัญมากในการจำสาขาและโต๊ะ)
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2. เช็คว่ามีไฟล์ .env อยู่จริงหรือไม่
$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) {
    die("<h3 style='color:red;'>ระบบหยุดทำงาน: ไม่พบไฟล์ .env</h3> <p>ตรวจสอบว่ามีไฟล์ .env อยู่ที่โฟลเดอร์ <b>" . realpath(__DIR__ . '/../') . "</b> หรือไม่</p>");
}

// 3. ฟังก์ชันสำหรับอ่านไฟล์ .env
function loadEnv($path) {
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        list($name, $value) = explode('=', $line, 2);
        putenv(trim($name) . '=' . trim($value));
    }
}
loadEnv($env_path);

// ==============================================================
// 4. ส่วนที่เพิ่มใหม่: ดักจับค่าจาก QR Code และบันทึกลงความจำ (Session)
// ==============================================================
if (isset($_GET['branch_id']) && isset($_GET['table_id'])) {
    $branch_id = (int)$_GET['branch_id'];
    $table_number = (int)$_GET['table_id']; // ค่าที่ส่งมาจากหน้าจัดการโต๊ะคือเบอร์โต๊ะ

    // บันทึกลง Session ให้ระบบจดจำพกติดตัวลูกค้าไปทุกหน้า
    $_SESSION['customer_branch_id'] = $branch_id;
    $_SESSION['customer_table_id'] = $table_number;
    // สร้างชื่อโต๊ะให้สวยงาม (เช่น T-01) เพื่อส่งไปแสดงในหน้า cart.php
    $_SESSION['customer_table_name'] = 'T-' . str_pad($table_number, 2, '0', STR_PAD_LEFT);

    // เมื่อจำค่าสำเร็จ ให้พาเข้าหน้าเมนูอัตโนมัติทันที
    header("Location: menu.php");
    exit;
}
// ==============================================================

// 5. เชื่อมต่อฐานข้อมูล
try {
    $host = getenv('DB_HOST');
    $dbname = getenv('DB_DATABASE');
    $user = getenv('DB_USERNAME');
    $pass = getenv('DB_PASSWORD');

    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ดึงข้อมูลการตั้งค่า
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

} catch (PDOException $e) {
    die("<h3 style='color:red;'>ระบบหยุดทำงาน: เชื่อมต่อฐานข้อมูลไม่ได้</h3> <p>Error: " . $e->getMessage() . "</p>");
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    
    <header class="text-white p-4 shadow-md text-center transition-colors" 
            style="background-color: <?php echo htmlspecialchars($settings['primary_color'] ?? '#3b82f6'); ?>;">
        <h1 class="text-2xl font-bold"><?php echo htmlspecialchars($settings['shop_name'] ?? 'ชื่อร้าน'); ?></h1>
        <p class="text-sm opacity-90 mt-1">ยินดีต้อนรับสู่ระบบสั่งเครื่องดื่มออนไลน์</p>
    </header>

    <main class="flex-grow p-4 max-w-md mx-auto w-full mt-4 space-y-4">
        <div class="bg-white p-6 rounded-xl shadow-sm text-center">
            <div class="mb-4 text-blue-500">
                <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"></path>
                </svg>
            </div>
            <h2 class="text-xl font-semibold mb-2 text-gray-800">กรุณาสแกน QR Code ที่โต๊ะ</h2>
            <p class="text-gray-500 text-sm mb-6">เพื่อดูเมนูและสั่งเครื่องดื่มสำหรับสาขานี้</p>
            
            <button class="w-full py-3 rounded-lg font-bold text-white transition-colors"
               style="background-color: <?php echo htmlspecialchars($settings['primary_color'] ?? '#3b82f6'); ?>;"
               onclick="window.location.href='menu.php'">
               เข้าสู่เมนูสั่งอาหาร
            </button>
        </div>
    </main>

</body>
</html>