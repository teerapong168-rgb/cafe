<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$env_path = __DIR__ . '/../.env';
if (!file_exists($env_path)) die("Error: Missing .env");
$env = parse_ini_file($env_path);

try {
    $pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_DATABASE']};charset=utf8mb4", $env['DB_USERNAME'], $env['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    $userStmt = $pdo->prepare("SELECT full_name, username, branch_id FROM users WHERE id = ?");
    $userStmt->execute([$_SESSION['admin_id']]);
    $currentUser = $userStmt->fetch(PDO::FETCH_ASSOC);
    $display_staff_name = !empty($currentUser['full_name']) ? $currentUser['full_name'] : $currentUser['username'];
    
    // ดึง branch_id มาจาก Session หรือ User
    $current_branch_id = $_SESSION['branch_id'] ?? null;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['new_status'])) {
        $order_id = (int)$_POST['order_id'];
        $new_status = $_POST['new_status'];
        $staff_id = $_SESSION['admin_id']; 
        
        $updateStmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $updateStmt->execute([$new_status, $order_id]);
        
        $orderStmt = $pdo->prepare("SELECT branch_id, total_amount FROM orders WHERE id = ?");
        $orderStmt->execute([$order_id]);
        $orderData = $orderStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($orderData) {
            $action_map = [
                'processing' => 'order_accepted',
                'ready_to_serve' => 'order_finished',
                'completed' => 'order_delivered'
            ];
            $action_type = $action_map[$new_status] ?? 'status_changed';
            
            $logStmt = $pdo->prepare("INSERT INTO transaction_logs (order_id, user_id, branch_id, action_type, amount) VALUES (?, ?, ?, ?, ?)");
            $logStmt->execute([$order_id, $staff_id, $orderData['branch_id'], $action_type, $orderData['total_amount']]);
            
            if ($new_status === 'ready_to_serve') {
                $qStmt = $pdo->prepare("SELECT queue_number FROM orders WHERE id = ?");
                $qStmt->execute([$order_id]);
                $_SESSION['call_queue'] = $qStmt->fetchColumn(); 
            }
        }
        
        header("Location: admin_orders.php");
        exit;
    }

    // --- ส่วนที่แก้ไข: กรองออเดอร์ตามสาขา พร้อม JOIN โต๊ะเพื่อดึง table_number ---
    if ($current_branch_id !== null) {
        $ordersStmt = $pdo->prepare("
            SELECT o.*, t.table_number 
            FROM orders o
            LEFT JOIN tables t ON o.table_id = t.id
            WHERE o.status NOT IN ('completed', 'voided') AND o.branch_id = ? 
            ORDER BY o.created_at ASC
        ");
        $ordersStmt->execute([$current_branch_id]);
        
        $latestPendingStmt = $pdo->prepare("SELECT MAX(id) FROM orders WHERE status = 'pending' AND branch_id = ?");
        $latestPendingStmt->execute([$current_branch_id]);
        $latest_pending_id = (int)$latestPendingStmt->fetchColumn();
    } else {
        $ordersStmt = $pdo->query("
            SELECT o.*, t.table_number 
            FROM orders o
            LEFT JOIN tables t ON o.table_id = t.id
            WHERE o.status NOT IN ('completed', 'voided') 
            ORDER BY o.created_at ASC
        ");
        
        $latestPendingStmt = $pdo->query("SELECT MAX(id) FROM orders WHERE status = 'pending'");
        $latest_pending_id = (int)$latestPendingStmt->fetchColumn();
    }
    
    $active_orders = $ordersStmt->fetchAll(PDO::FETCH_ASSOC);

    $order_items = [];
    if (!empty($active_orders)) {
        $order_ids = array_column($active_orders, 'id');
        $inQuery = implode(',', array_fill(0, count($order_ids), '?'));
        
        $itemsStmt = $pdo->prepare("
            SELECT oi.*, p.name 
            FROM order_items oi 
            JOIN products p ON oi.product_id = p.id 
            WHERE oi.order_id IN ($inQuery)
        ");
        $itemsStmt->execute($order_ids);
        
        foreach ($itemsStmt->fetchAll(PDO::FETCH_ASSOC) as $item) {
            $order_items[$item['order_id']][] = $item;
        }
    }

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

function getStatusDisplay($status) {
    $map = [
        'pending' => ['text' => 'รอดำเนินการ', 'color' => 'bg-red-100 text-red-700', 'next_action' => 'processing', 'btn_text' => 'รับออเดอร์นี้'],
        'processing' => ['text' => 'กำลังทำ', 'color' => 'bg-yellow-100 text-yellow-700', 'next_action' => 'ready_to_serve', 'btn_text' => 'ทำเสร็จแล้ว'],
        'ready_to_serve' => ['text' => 'รอเสิร์ฟ', 'color' => 'bg-green-100 text-green-700', 'next_action' => 'completed', 'btn_text' => 'ส่งมอบแล้ว (จบงาน)'],
    ];
    return $map[$status] ?? ['text' => 'ไม่ทราบ', 'color' => 'bg-gray-100 text-gray-700', 'next_action' => '', 'btn_text' => ''];
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="10">
    <title>หน้าจอรับออเดอร์ - <?php echo htmlspecialchars($settings['shop_name'] ?? 'My Cafe'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

    <header class="bg-gray-900 text-white p-4 sticky top-0 z-50 shadow-md flex justify-between items-center flex-wrap gap-4">
        <div class="flex items-center space-x-4">
            <h1 class="text-xl font-bold">POS / KDS Dashboard</h1>
            <span class="bg-green-500 text-xs px-2 py-1 rounded animate-pulse">Live Auto-Update</span>
            
            <!-- แจ้งพนักงานให้รู้ว่ากำลังดูออเดอร์สาขาไหนอยู่ -->
            <span class="bg-indigo-600 border border-indigo-400 text-xs px-2 py-1 rounded font-bold shadow-sm">
                <?php echo $current_branch_id ? '📍 สาขา: ' . $current_branch_id : '👑 Super Admin (รวมทุกสาขา)'; ?>
            </span>
        </div>
        
        <div class="flex items-center space-x-3">
            <button id="soundToggleBtn" onclick="toggleSound()" class="text-sm bg-gray-600 hover:bg-green-600 text-white px-3 py-1.5 rounded transition shadow-sm font-bold flex items-center space-x-1">
                <span>🔇 ระบบเสียง</span>
            </button>

            <div class="text-sm font-semibold bg-gray-800 px-3 py-1 rounded border border-gray-700 flex items-center space-x-2 hidden md:flex">
                <span>👤 <span class="text-blue-300"><?php echo htmlspecialchars($display_staff_name); ?></span></span>
            </div>
            
            <div class="text-sm font-semibold text-yellow-400">
                รอทำ: <?php echo count($active_orders); ?> คิว
            </div>
            
            <?php if ($_SESSION['admin_role'] === 'staff'): ?>
                <a href="logout.php" title="ออกจากระบบ" class="text-sm bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded transition flex items-center space-x-1 shadow-sm">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                    <span class="hidden sm:inline">ปิดระบบ</span>
                </a>
            <?php else: ?>
                <a href="admin_dashboard.php" class="text-sm bg-gray-700 hover:bg-gray-600 text-white px-3 py-1.5 rounded transition">แดชบอร์ด</a>
            <?php endif; ?>
        </div>
    </header>

    <main class="p-6">
        <?php if (empty($active_orders)): ?>
            <div class="text-center text-gray-500 mt-20">
                <svg class="w-20 h-20 mx-auto text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path></svg>
                <h2 class="text-2xl font-bold">ยังไม่มีออเดอร์ในขณะนี้</h2>
                <p>หน้าจอจะรีเฟรชอัตโนมัติทุกๆ 10 วินาที...</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                <?php foreach ($active_orders as $order): 
                    $display = getStatusDisplay($order['status']);
                    // ใช้ table_number ที่ได้จากการ JOIN
                    $display_table = $order['table_number'] ? str_pad($order['table_number'], 2, '0', STR_PAD_LEFT) : 'ไม่ระบุ';
                ?>
                    <div class="bg-white rounded-xl shadow-md overflow-hidden border-t-4 border-blue-500 flex flex-col">
                        <div class="p-4 border-b bg-gray-50 flex justify-between items-start">
                            <div>
                                <h3 class="text-2xl font-black text-gray-800"><?php echo htmlspecialchars($order['queue_number']); ?></h3>
                                <p class="text-sm font-bold text-gray-500">โต๊ะ: T-<?php echo $display_table; ?></p>
                            </div>
                            <div class="flex flex-col items-end gap-1">
                                <span class="px-3 py-1 rounded-full text-xs font-bold <?php echo $display['color']; ?>">
                                    <?php echo $display['text']; ?>
                                </span>
                                <?php if ($current_branch_id === null): ?>
                                    <span class="text-xs font-bold text-indigo-500">สาขา: <?php echo $order['branch_id']; ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="p-4 flex-grow bg-white">
                            <ul class="space-y-3">
                                <?php if (isset($order_items[$order['id']])): ?>
                                    <?php foreach ($order_items[$order['id']] as $item): ?>
                                        <li class="flex justify-between items-center border-b border-dashed pb-2">
                                            <span class="font-semibold text-lg text-gray-800">
                                                <span class="text-blue-600 mr-2"><?php echo $item['quantity']; ?>x</span> 
                                                <?php echo htmlspecialchars($item['name']); ?>
                                            </span>
                                        </li>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </ul>
                        </div>

                        <div class="p-4 bg-gray-50 border-t">
                            <div class="flex justify-between items-start mb-4">
                                <div>
                                    <span class="text-sm font-semibold text-gray-500 block">ชำระ: <?php echo $order['payment_method'] == 'qr_promptpay' ? 'สแกนจ่าย' : 'เงินสด'; ?></span>
                                    <?php if ($order['payment_method'] == 'qr_promptpay' && !empty($order['payment_slip_url'])): ?>
                                        <a href="<?php echo ltrim(htmlspecialchars($order['payment_slip_url']), '/'); ?>" target="_blank" class="inline-block mt-1 text-sm text-blue-600 font-bold hover:underline">🔍 ดูสลิป</a>
                                    <?php endif; ?>
                                </div>
                                <span class="text-xl font-black text-gray-900">฿<?php echo number_format($order['total_amount'], 2); ?></span>
                            </div>

                            <?php if ($display['next_action']): ?>
                                <form method="POST" action="">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <input type="hidden" name="new_status" value="<?php echo $display['next_action']; ?>">
                                    <button type="submit" class="w-full py-3 rounded-lg font-bold text-white shadow-sm hover:opacity-90 transition
                                        <?php echo $order['status'] == 'pending' ? 'bg-blue-600' : ($order['status'] == 'processing' ? 'bg-yellow-500' : 'bg-green-600'); ?>">
                                        <?php echo $display['btn_text']; ?>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <!-- Script สำหรับเล่นเสียง -->
    <script>
        function updateSoundBtn() {
            let btn = document.getElementById('soundToggleBtn');
            if (localStorage.getItem('kdsSoundEnabled') === 'true') {
                btn.innerHTML = '🔊 เปิดเสียงแล้ว';
                btn.classList.replace('bg-gray-600', 'bg-green-600');
            } else {
                btn.innerHTML = '🔇 ปิดเสียงอยู่';
                btn.classList.replace('bg-green-600', 'bg-gray-600');
            }
        }

        function toggleSound() {
            let isEnabled = localStorage.getItem('kdsSoundEnabled') === 'true';
            localStorage.setItem('kdsSoundEnabled', !isEnabled);
            updateSoundBtn();
            if (!isEnabled) {
                playNewOrderSound(); 
            }
        }

        function playNewOrderSound() {
            try {
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const playTone = (freq, time, duration) => {
                    const osc = ctx.createOscillator();
                    const gain = ctx.createGain();
                    osc.connect(gain);
                    gain.connect(ctx.destination);
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(freq, time);
                    gain.gain.setValueAtTime(0.5, time);
                    gain.gain.exponentialRampToValueAtTime(0.01, time + duration);
                    osc.start(time);
                    osc.stop(time + duration);
                };
                let now = ctx.currentTime;
                playTone(1046.50, now, 0.3); 
                playTone(1318.51, now + 0.15, 0.5); 
            } catch (e) { console.log('Audio error:', e); }
        }

        if ('speechSynthesis' in window) {
            window.speechSynthesis.onvoiceschanged = function() {
                window.speechSynthesis.getVoices();
            };
        }

        function callQueue(qNum) {
            try {
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.type = 'sine';
                osc.frequency.setValueAtTime(659.25, ctx.currentTime); 
                gain.gain.setValueAtTime(0.5, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.8);
                osc.start(ctx.currentTime);
                osc.stop(ctx.currentTime + 0.8);

                setTimeout(() => {
                    const osc2 = ctx.createOscillator();
                    const gain2 = ctx.createGain();
                    osc2.connect(gain2);
                    gain2.connect(ctx.destination);
                    osc2.type = 'sine';
                    osc2.frequency.setValueAtTime(523.25, ctx.currentTime); 
                    gain2.gain.setValueAtTime(0.5, ctx.currentTime);
                    gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.0);
                    osc2.start(ctx.currentTime);
                    osc2.stop(ctx.currentTime + 1.0);
                }, 400);

                setTimeout(() => {
                    if ('speechSynthesis' in window) {
                        let spokenQ = qNum.replace('Q-', '').split('').join(' '); 
                        let textToSpeak = "เชิญหมายเลขคิว ... " + spokenQ + " ... ค่ะ , , , เชิญหมายเลขคิว ... " + spokenQ + " ... ค่ะ";
                        
                        let msg = new SpeechSynthesisUtterance(textToSpeak);
                        msg.lang = 'th-TH';
                        msg.rate = 0.70;  
                        msg.pitch = 1.4;  

                        let voices = window.speechSynthesis.getVoices();
                        let thaiVoices = voices.filter(v => v.lang.includes('th') || v.lang.includes('TH'));
                        
                        if (thaiVoices.length > 0) {
                            let femaleVoice = thaiVoices.find(v => 
                                v.name.toLowerCase().includes('female') || 
                                v.name.toLowerCase().includes('premwadee') || 
                                v.name.toLowerCase().includes('thida') ||
                                v.name.toLowerCase().includes('kanya') ||
                                v.name.toLowerCase().includes('siri')
                            );
                            msg.voice = femaleVoice ? femaleVoice : thaiVoices[0];
                        }

                        window.speechSynthesis.speak(msg);
                    }
                }, 1300);

            } catch (e) { console.log('Speech error:', e); }
        }

        window.addEventListener('DOMContentLoaded', () => {
            updateSoundBtn();
            let soundEnabled = localStorage.getItem('kdsSoundEnabled') === 'true';

            const latestPending = <?php echo $latest_pending_id; ?>;
            let lastPending = parseInt(localStorage.getItem('lastPendingOrderId') || 0);
            
            if (latestPending > lastPending) {
                localStorage.setItem('lastPendingOrderId', latestPending);
                if (soundEnabled) {
                    playNewOrderSound();
                }
            }

            <?php if (isset($_SESSION['call_queue'])): ?>
                if (soundEnabled) {
                    callQueue("<?php echo $_SESSION['call_queue']; ?>");
                }
                <?php unset($_SESSION['call_queue']); ?>
            <?php endif; ?>
        });
    </script>
</body>
</html>