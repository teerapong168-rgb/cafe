-- 1. ตารางตั้งค่าระบบ (Dynamic Settings) สำหรับเปลี่ยนชื่อร้าน/สี/โลโก้
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `setting_key` VARCHAR(50) NOT NULL UNIQUE,
  `setting_value` TEXT,
  `description` VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- เพิ่มข้อมูลตั้งค่าเริ่มต้น
INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES
('shop_name', 'My Cafe', 'ชื่อร้าน'),
('primary_color', '#3b82f6', 'สีหลักของเว็บ'),
('promptpay_no', '', 'เบอร์พร้อมเพย์รับเงิน');

-- 2. ตารางผู้ใช้งานระบบ (Admin / Staff)
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('superadmin', 'manager', 'staff') NOT NULL DEFAULT 'staff',
  `branch_id` INT NULL COMMENT 'ถ้าเป็น superadmin จะเป็น NULL',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. ตารางสาขา (Branches)
CREATE TABLE IF NOT EXISTS `branches` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `address` TEXT,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. ตารางโต๊ะและ QR Code (Tables)
CREATE TABLE IF NOT EXISTS `tables` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `branch_id` INT NOT NULL,
  `table_number` VARCHAR(20) NOT NULL,
  `qr_token` VARCHAR(64) NOT NULL UNIQUE COMMENT 'ใช้สำหรับสร้าง URL QR Code',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. ตารางหมวดหมู่เมนู (Categories)
CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `sort_order` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. ตารางเมนูสินค้า (Products)
CREATE TABLE IF NOT EXISTS `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT,
  `name` VARCHAR(150) NOT NULL,
  `price` DECIMAL(10, 2) NOT NULL,
  `image_url` VARCHAR(255),
  `status` ENUM('available', 'out_of_stock', 'hidden') DEFAULT 'available',
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. ตารางออเดอร์หลัก (Orders) - แยกบิลตามคิว
CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `queue_number` VARCHAR(20) NOT NULL COMMENT 'เช่น Q-001',
  `branch_id` INT NOT NULL,
  `table_id` INT NULL COMMENT 'สั่งกลับบ้านจะเป็น NULL',
  `total_amount` DECIMAL(10, 2) NOT NULL,
  `payment_method` ENUM('qr_promptpay', 'cash_at_counter') NOT NULL,
  `payment_slip_url` VARCHAR(255) NULL COMMENT 'เก็บรูปสลิปถ้าลูกค้าโอน',
  `status` ENUM('pending', 'paid_waiting', 'processing', 'ready_to_serve', 'completed', 'voided') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`branch_id`) REFERENCES `branches`(`id`),
  FOREIGN KEY (`table_id`) REFERENCES `tables`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. ตารางรายการเมนูในออเดอร์ (Order Items)
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `price_per_unit` DECIMAL(10, 2) NOT NULL,
  `options_json` JSON NULL COMMENT 'เก็บพวก หวานน้อย, เพิ่มช็อต',
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. ตารางบันทึกการเงิน (Transaction Logs)
CREATE TABLE IF NOT EXISTS `transaction_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT NOT NULL,
  `branch_id` INT NOT NULL,
  `action_type` VARCHAR(50) NOT NULL COMMENT 'slip_uploaded, payment_approved, voided',
  `performed_by` INT NULL COMMENT 'NULL ถ้าระบบ/ลูกค้าทำ',
  `amount` DECIMAL(10, 2) NOT NULL,
  `remark` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. ตารางบันทึกประวัติการใช้งานระบบ (Audit Logs)
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `module` VARCHAR(50) NOT NULL COMMENT 'Menu, Branch, User',
  `action` VARCHAR(50) NOT NULL COMMENT 'Created, Updated, Deleted',
  `old_values` JSON NULL,
  `new_values` JSON NULL,
  `ip_address` VARCHAR(45),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;